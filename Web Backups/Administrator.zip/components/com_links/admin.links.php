<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );
require_once("class.links.php");
require_once("components/com_category/class.category.php");

$cid = josGetArrayInts( 'cid' );

switch ($task) {
	case 'new':
		editLinks( 0 );
		break;

	case 'edit':
		editLinks( $id );
		break;

	case 'apply':
	case 'save':
		saveItem( $task );
		break;

	case 'remove':
		removeItem( $cid, 'links' );
		break;
	
	case 'cancelLinks':
	default:
		viewLinks();
		break;
}

// Link Functions
function viewLinks() {
	global $database, $mainframe, $mosConfig_list_limit,  $my, $acl, $mosConfig_offset;
	
	$limit = intval( mosGetParam( $_REQUEST, 'limit', $mosConfig_list_limit ) );
	$limitstart = intval( mosGetParam( $_REQUEST, 'limitstart', 0 ) );
	$filter_type = intval( $mainframe->getUserStateFromRequest( "filter_type", 'filter_type', 0 ) );

	$rows[] = mosHTML::makeOption( '0', '-- Show All --', 'id', 'Title' );
	$database->setQuery( "SELECT id,Title FROM #__links_sections" );
	$rows = array_merge( $rows, $database->loadObjectList() );
	
	$lists['type'] = mosHTML::selectList( $rows, 'filter_type', 'size="1" onchange="document.adminForm.submit();"', 'id', 'Title', $filter_type );
	
	if ( $filter_type > 0 ) {
		$where = " WHERE b.section_id = ".$filter_type;
		
		$count_query = "SELECT count(*) FROM #__links a INNER JOIN ( SELECT DISTINCT b.link_id FROM #__linksSections b, #__links_sections c".$where." ) d ON a.id = d.link_id";
		$query = "SELECT a.* FROM #__links a INNER JOIN ( SELECT DISTINCT b.link_id FROM #__linksSections b, #__links_sections c".$where." ) d ON a.id = d.link_id ORDER BY ordering ASC";
	}
	else
	{
		$count_query = "SELECT count(*) FROM #__links";
		$query = "SELECT * FROM #__links ORDER BY ordering ASC";
	}

	// get the total number of records
	$database->setQuery( $count_query );
	$total = $database->loadResult();
	
	require_once( $GLOBALS['mosConfig_absolute_path'] . '/administrator/includes/pageNavigation.php' );
	$pageNav = new mosPageNav( $total, $limitstart, $limit );
	
	$database->setQuery( $query, $pageNav->limitstart, $pageNav->limit );
	$rows = $database->loadObjectList();

	if ($database->getErrorNum()) {
		echo $database->stderr();
		return false;
	}

	mosCommonHTML::loadOverlib();
	?>
	<form enctype="multipart/form-data" action="index2.php?option=com_links" method="post" name="adminForm">
		<table class="adminheading">
			<tr><th class="edit" rowspan="2" nowrap="nowrap">Manage Links</th></tr>
			<td align="right" valign="top"><?php echo $lists['type'];?></td>
		</table>
		<table class="adminlist">
			<tr>
				<th width="5">#</th>
				<th width="5"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $rows ); ?>);" /></th>
				<th class="title">Title</th>
				<th>Published</th>
			</tr><?php
		$k = 0;
		$nullDate = $database->getNullDate();
		for ($i=0, $n=count( $rows ); $i < $n; $i++) {
			$row = &$rows[$i];
	
			mosMakeHtmlSafe($row);
	
			$link = 'index2.php?option=com_links&task=edit&id='.$row->id; ?>
			<tr class="<?= "row$k" ?>">
				<td><?= $pageNav->rowNumber( $i ) ?></td>
				<td align="center"><?php echo "<input type='checkbox' id='cb$i' name='cid[]' value='$row->id' onclick='isChecked(this.checked);' />"; ?></td>
				<td>
					<?php
					if ( $row->checked_out && ( $row->checked_out != $my->id )) {
						echo $row->Title;
					} else {
						?><a href="<?= $link ?>" title="Edit Content"><?= $row->Title ?></a><?php
					}
					?>
				</td>
				<td align="center"><?= $row->Published ?></td>
			</tr><?php
			$k = 1 - $k;
		}
		?>
		</table>
		<?php echo $pageNav->getListFooter(); ?>
		<input type="hidden" name="option" value="com_links" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="hidemainmenu" value="0" />
	</form><?php
}

function editLinks( $uid=0 ) {
	global $database, $my, $mainframe, $mosConfig_absolute_path, $mosConfig_live_site, $mosConfig_offset;
	
	$option = strval( mosGetParam( $_REQUEST, 'option', '' ) );

	// load the row from the db table
	$row = new mosLinks( $database );
	$row->load( (int)$uid );

	$selected_folders = NULL;
	if ( $uid == 0 ) {
		$row->Title = '';
		$row->Copy = '';
		$row->LinkName = '';
		$row->Url = 'http://';
		$row->Published = 'true';
		$row->Target = 'true';
	}

	mosMakeHtmlSafe( $row );

	mosCommonHTML::loadOverlib();
	mosCommonHTML::loadCalendar();
	?>
	<script language="javascript" type="text/javascript">
	<!--
	function submitbutton(pressbutton) {
		var form = document.adminForm;

		if (pressbutton == 'cancel') {
			submitform( pressbutton );
			return;
		}
		
		if (pressbutton == 'preview') {
			window.open('popups/preview.php?option=<?php echo $option; ?>&id=<?php echo $row->id ?>', 'win1', 'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no');
		}
		else if (form.Title.value == ""){
			alert( "You Must enter a Title" );
		} else {
			<?php getEditorContents( 'editor1', 'Copy' ) ; ?>
			submitform( pressbutton );
		}
	}
	//-->
	</script>
	<form enctype="multipart/form-data" action="index2.php" method="post" name="adminForm">
		<table class="adminheading">
			<tr><th class="edit"><?php echo $row->id ? 'Edit' : 'Add';?> Link</th></tr>
		</table>
		<table align="left" cellspacing="0" cellpadding="0" width="60%">
			<tr>
				<td width="60%" valign="top">
					<table width="100%" class="adminform">
						<tr>
							<td width="100%">
								<table cellspacing="0" cellpadding="0" border="0" width="100%">
									<tr><th colspan="4">Links Details</th></tr>
									<tr>
										<td>Published:</td>
										<td><input class="text_area" type="checkbox" name="Published"  value="true" <?= $row->Published == 'true' ? 'checked="checked"' : '' ?> /></td>
									</tr>
									<tr>
										<td>Title:</td>
										<td><input class="text_area" type="text" name="Title" size="30" maxlength="100" value="<?= $row->Title ?>" /></td>
									</tr>
									<tr>
										<td>Url:</td>
										<td><input class="text_area" type="text" name="Url" size="30" maxlength="100" value="<?= $row->Url ?>" /></td>
									</tr>
									<tr>
										<td>Categories:</td>
										<td>
											<table width="100%"><?php
											// Get Selected Sections
											$database->setQuery( "SELECT section_id FROM #__linksSections WHERE link_id = ".$row->id );
											$Sections = $database->loadResultArray();
											$Sections = empty( $Sections ) ? array() : $Sections;
											
											$database->setQuery( "SELECT id,Title FROM #__links_sections ORDER BY Title ASC" );
											$cats = $database->loadObjectList();
											
											$array_len = count( $cats );
											$columns = 2;
											$rows = ceil( $array_len/$columns );
											
											$k = 0;
											for( $j = 0; $j < $rows; ++$j ) { ?>
												<tr><?php
												for( $i = 0; $i < $columns; ++$i ) { ?><td><?php
													if( isset($cats[$k]) ) { ?>
														<input class="text_area" type="checkbox" name="Section[]" value="<?= $cats[$k]->id ?>"<?= array_search( $cats[$k]->id, $Sections ) !== false ? ' checked="checked"' : ''; ?> />
														<?= $cats[$k]->Title ?><?php
													}
													else { ?>
														&nbsp;<?php
													} ?>
													</td><?php
													$k++;
												} ?>

												</tr><?php
											} ?>
											</table>
										</td>
									</tr>
									<tr>
										<td>Open in<br />New Window:</td>
										<td><input class="text_area" type="checkbox" name="Target" value="true"<? echo $row->Target == 'true' ? ' checked="checked"' : ''; ?> /></td>
									</tr>
									<?= displayUploadFile( $row, "Photo", "/data/links/images/", "image"  ) ?>
									<tr>
										<td>Copy:</td>
										<td><?php editorArea( 'editor1', $row->Copy, 'Copy', '100%;', '250', '65', '15' ); ?></td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<input type="hidden" name="id" value="<?= $row->id ?>" />
		<input type="hidden" name="option" value="com_links" />
		<input type="hidden" name="task" value="save" />
	</form><?php
}

function saveItem( $task ) {
	global $database, $my, $mainframe, $mosConfig_offset, $mosConfig_absolute_path;

	uploadFile2( "data/links/images", "Photo");
	
	$row = new mosLinks( $database );
	if (!$row->bind( $_POST )) {
		echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
		exit();
	}
	// sanitise id field
	$row->id = (int) $row->id;
	
 	if (!$row->check()) {
		echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
		exit();
	}
	
	$row->Published = strval( mosGetParam( $_REQUEST, 'Published', 'false' ) );
	$row->Target = strval( mosGetParam( $_REQUEST, 'Target', 'false' ) );

	$row->store();
	
	// Finding all the entries not checked.
	$where = "";
	$first_time = true;
	if( !empty( $row->Section ) ) {
		foreach($row->Section as $s ) {
			if( $first_time == false )
				$where .= " AND";
			else {
				$where .= " WHERE";
				$first_time = false;
			}
			$where .= " (id <> ".$s.")";
			
			$sql = "INSERT INTO #__linksSections (link_id, section_id) VALUES (".$row->id.",".$s.")";
			$database->setQuery($sql);
			$database->query();
		}
	}
	
	$sql = "SELECT id FROM #__links_sections".$where;
	$database->setQuery($sql);
	$rows = $database->loadObjectList();
	
	foreach( $rows as $r ) {
		$sql = "DELETE FROM #__linksSections WHERE link_id = ".$row->id." AND section_id = ".$r->id;
		$database->setQuery($sql);
		$database->query();
	}

	// clean any existing cache files
	mosCache::cleanCache( 'com_links' );
	
	switch ( $task ) {
		case 'apply':
			$msg = 'Successfully Saved changes to Item: '. $row->Title;
			mosRedirect( 'index2.php?option=com_links&task=edit&id='. $row->id, $msg );
			break;

		case 'save':
		default:
			mosRedirect( 'index2.php?option=com_links' );
			break;
	}
}

function removeItem( &$cid, $table ) {
	global $database;

	$total = count( $cid );
	if ( $total < 1) {
		echo "<script> alert('Select an item to delete'); window.history.go(-1);</script>\n";
		exit;
	}

	//seperate contentids
	mosArrayToInts( $cid );
	$cids = 'id=' . implode( ' OR id=', $cid );
	$query = "DELETE FROM #__".$table." WHERE ( $cids )";
	$database->setQuery( $query );
	if ( !$database->query() ) {
		echo "<script> alert('".$database->getErrorMsg()."'); window.history.go(-1); </script>\n";
		exit();
	}

	// clean any existing cache files
	mosCache::cleanCache( 'com_'.$table );

	$msg = $total ." Item(s) sent to the Trash";
	mosRedirect( 'index2.php?option=com_'.$table, $msg );
}
?>