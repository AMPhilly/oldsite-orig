<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class mosLinks extends mosDBTable {
	var $id			=null;
	var $Title		=null;
	var $Section	=null;
	var $Copy		=null;
	var $Url		=null;
	var $Photo		=null;
	var $LinkName	=null;
	var $Target		=null;
	var $Published	=null;
	var $ordering	=null;
	
	function mosLinks( &$db ) {
		$this->mosDBTable( '#__links', 'id', $db );
	}
	
	function schema() {
		return " CREATE TABLE IF NOT EXISTS `J_links` (
		`id` INT( 11 ) UNSIGNED NOT NULL AUTO_INCREMENT ,
		`Title` VARCHAR( 255 ) NOT NULL ,
		`Copy` TEXT NOT NULL ,
		`Photo` VARCHAR( 255 ) NOT NULL ,
		`Url` VARCHAR( 255 ) NOT NULL ,
		`LinkName` VARCHAR( 255 ) NOT NULL ,
		`Target` ENUM( 'false', 'true' ) NOT NULL DEFAULT 'false' ,
		`Published` ENUM( 'false', 'true' ) NOT NULL DEFAULT 'false' ,
		`ordering` INT( 11 ) NOT NULL ,
		PRIMARY KEY ( `id` ) ,
		INDEX ( `Section` )
		) ENGINE = MYISAM,";
	}
}
?>
