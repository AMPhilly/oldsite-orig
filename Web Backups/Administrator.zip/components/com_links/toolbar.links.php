<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );

require_once( $mainframe->getPath( 'toolbar_html' ) );

switch ($task) {
	case 'new':
	case 'edit':
	case 'editA':
		TOOLBAR_links::_EDIT( );
		break;
	
	case 'viewLinks':
		TOOLBAR_links::_VIEWLINKS( );
		break;

	default:
		TOOLBAR_links::_DEFAULT();
		break;
}
?>