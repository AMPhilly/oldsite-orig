<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class mosNews extends mosDBTable {
	var $id				=null;
	var $Section		=null;
	var $Title			=null;
	var $SubTitle		=null;
	var $Author			=null;
	var $Publication	=null;
	var $OriginalDate	=null;
	var $Date			=null;
	var $StartPublish	=null;
	var $EndPublish		=null;
	var $Comment		=null;
	var $Article		=null;
	var $LinkName		=null;
	var $Url			=null;
	var $Photo1			=null;
	var $Caption1		=null;
	var $Alt1			=null;
	var $Photo2			=null;
	var $Caption2		=null;
	var $Alt2			=null;
	var $Photo3			=null;
	var $Caption3		=null;
	var $Alt3			=null;
	var $Photo4			=null;
	var $Caption4		=null;
	var $Alt4			=null;
	var $Photo5			=null;
	var $Caption5		=null;
	var $Alt5			=null;
	var $Photo6			=null;
	var $Caption6		=null;
	var $Alt6			=null;
	var $Gallery		=null;
	var $DocumentLink	=null;
	var $Document		=null;
	var $OnHomepage		=null;
	var $Archived		=null;
	var $Published		=null;
	var $ordering		=null;
	
	function mosNews( &$db ) {
		$this->mosDBTable( '#__news', 'id', $db );
	}
	
	function schema() {
		 return "CREATE TABLE IF NOT EXISTS `J_news` (
		  `id` int(11) unsigned NOT NULL auto_increment,
		  `Section` enum('Animal','Buzzy') NOT NULL,
		  `Title` varchar(255) NOT NULL,
		  `SubTitle` varchar(255) NOT NULL,
		  `Author` varchar(255) NOT NULL,
		  `Publication` varchar(255) NOT NULL,
		  `OriginalDate` varchar(255) NOT NULL,
		  `Date` date NOT NULL,
		  `StartPublish` date NOT NULL,
		  `EndPublish` date NOT NULL,
		  `Comment` text NOT NULL,
		  `Article` text NOT NULL,
		  `LinkName` varchar(255) NOT NULL,
		  `Url` varchar(255) NOT NULL,
		  `Photo1` varchar(255) NOT NULL,
		  `Caption1` varchar(255) NOT NULL,
		  `Alt1` varchar(255) NOT NULL,
		  `Photo2` varchar(255) NOT NULL,
		  `Caption2` varchar(255) NOT NULL,
		  `Alt2` varchar(255) NOT NULL,
		  `Photo3` varchar(255) NOT NULL,
		  `Caption3` varchar(255) NOT NULL,
		  `Alt3` varchar(255) NOT NULL,
		  `Photo4` varchar(255) NOT NULL,
		  `Caption4` varchar(255) NOT NULL,
		  `Alt4` varchar(255) NOT NULL,
		  `Photo5` varchar(255) NOT NULL,
		  `Caption5` varchar(255) NOT NULL,
		  `Alt5` varchar(255) NOT NULL,
		  `Photo6` varchar(255) NOT NULL,
		  `Caption6` varchar(255) NOT NULL,
		  `Alt6` varchar(255) NOT NULL,
		  `Gallery` int(11) NOT NULL,
		  `DocumentLink` varchar(255) NOT NULL,
		  `Document` varchar(255) NOT NULL,
		  `OnHomepage` enum('false','true') NOT NULL default 'false',
		  `Archived` enum('false','true') NOT NULL default 'false',
		  `Published` enum('false','true') NOT NULL default 'false',
		  `ordering` int(11) NOT NULL,
		  PRIMARY KEY  (`id`)
		) ENGINE=MyISAM;";
	}
	
	function insert_into_components() {
		return "INSERT INTO `J_components` (
				`id` ,
				`name` ,
				`link` ,
				`menuid` ,
				`parent` ,
				`admin_menu_link` ,
				`admin_menu_alt` ,
				`option` ,
				`ordering` ,
				`admin_menu_img` ,
				`iscore` ,
				`params`
				)
				VALUES (
				NULL , 'News', 'option=com_news', '0', '0', 'News', 'News', 'com_news', '0', '', '0', ''
				);";
	}
}
?>
