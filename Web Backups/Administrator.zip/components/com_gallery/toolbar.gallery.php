<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );

require_once( $mainframe->getPath( 'toolbar_html' ) );

switch ($task) {
	case 'new':
	case 'edit':
	case 'editA':
		TOOLBAR_gallery::_EDIT( );
		break;
		
	case 'newPhoto':
	case 'editPhoto':
		TOOLBAR_gallery::_EDITPHOTO( );
		break;
	
	case 'viewPhoto':
		TOOLBAR_gallery::_VIEWPHOTO();
		break;

	default:
		TOOLBAR_gallery::_DEFAULT();
		break;
}
?>