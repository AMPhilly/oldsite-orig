<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class mosPhoto extends mosDBTable {
	var $id=null;
	var $GID=null;
	var $Name=null;
	var $Photo=null;
	var $Caption=null;
	var $ordering=null;
	var $Published=null;
	
	function mosPhoto( &$db ) {
		$this->mosDBTable( '#__photo', 'id', $db );
	}
	
	function schema() {
		return "CREATE TABLE IF NOT EXISTS `J_photo` (
		`id` INT( 11 ) UNSIGNED NOT NULL AUTO_INCREMENT ,
		`GID` INT UNSIGNED NOT NULL ,
		`Name` VARCHAR( 255 ) NOT NULL ,
		`Photo` VARCHAR( 255 ) NOT NULL ,
		`Caption` VARCHAR( 255 ) NOT NULL ,
		`Alt` VARCHAR( 255 ) NOT NULL ,
		`Published` ENUM( 'false', 'true' ) NOT NULL DEFAULT 'false',
		PRIMARY KEY ( `id` ) ,
		INDEX ( `GID` )
		) ENGINE = MYISAM;";
	} 
}
?>
