<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class mosGallery extends mosDBTable {
	var $id=null;
	var $Name=null;
	var $Description=null;
	var $Caption=null;
	var $ordering=null;
	var $Published=null;
	
	function mosGallery( &$db ) {
		$this->mosDBTable( '#__gallery', 'id', $db );
	}
	
	function schema() {
		return "CREATE TABLE IF NOT EXISTS `J_gallery` (
		`id` INT( 11 ) UNSIGNED NOT NULL AUTO_INCREMENT ,
		`Name` VARCHAR( 255 ) NOT NULL ,
		`Description` TEXT NOT NULL ,
		`Published` ENUM( 'false', 'true' ) NOT NULL DEFAULT 'false',
		PRIMARY KEY ( `id` )
		) ENGINE = MYISAM;";
	}
}
?>
