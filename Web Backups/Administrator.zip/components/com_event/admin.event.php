<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );
require_once("class.event.php");

$cid = josGetArrayInts( 'cid' );

switch ($task) {
	case 'orderup':
		order( $cid[0], -1, $option );
		break;

	case 'orderdown':
		order( $cid[0], 1, $option );
		break;

	case 'new':
		editEvent( 0 );
		break;

	case 'edit':
		editEvent( $id );
		break;

	case 'save':
	case 'apply':
		saveItem( $task );
		break;

	case 'remove':
		removeItem( $cid, 'event' );
		break;

	default:
		viewEvent();
		break;
}

function viewEvent() {
	global $database, $mainframe, $mosConfig_list_limit,  $my, $acl, $mosConfig_offset;
	
	$limit = intval( mosGetParam( $_REQUEST, 'limit', $mosConfig_list_limit ) );
	$limitstart = intval( mosGetParam( $_REQUEST, 'limitstart', 0 ) );

	// get the total number of records
	$query = "SELECT count(*) FROM #__event";
	
	$database->setQuery( $query );
	$total = $database->loadResult();
	
	require_once( $GLOBALS['mosConfig_absolute_path'] . '/administrator/includes/pageNavigation.php' );
	$pageNav = new mosPageNav( $total, $limitstart, $limit );

	$query = "SELECT * FROM #__event ORDER BY ordering ASC";
	$database->setQuery( $query, $pageNav->limitstart, $pageNav->limit );
	$rows = $database->loadObjectList();

	if ($database->getErrorNum()) {
		echo $database->stderr();
		return false;
	}

	mosCommonHTML::loadOverlib();
	?>
	<form enctype="multipart/form-data" action="index2.php?option=com_event" method="post" name="adminForm">
	<table class="adminheading">
		<tr><th class="edit" rowspan="2" nowrap="nowrap">Manage Events</th></tr>
	</table>
	<table class="adminlist">
		<tr>
			<th width="5">#</th>
			<th width="5"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $rows ); ?>);" /></th>
			<th class="title">Event Name</th>
			<th colspan="2">ReOrder</th>
			<th>Archived</th>
			<th>Published</th>
		</tr>
	<?php
	$k = 0;
	$nullDate = $database->getNullDate();
	for ($i=0, $n=count( $rows ); $i < $n; $i++) {
		$row = &$rows[$i];

		mosMakeHtmlSafe($row);

		$link = 'index2.php?option=com_event&task=edit&id='. $row->id;

		$access 	= mosCommonHTML::AccessProcessing( $row, $i );
		$checked 	= mosCommonHTML::CheckedOutProcessing( $row, $i );
		?>
		<tr class="<?= "row$k" ?>">
			<td><?= $pageNav->rowNumber( $i ) ?></td>
			<td align="center"><?php echo "<input type='checkbox' id='cb$i' name='cid[]' value='$row->id' onclick='isChecked(this.checked);' />"; ?></td>
			<td>
				<?php
				if ( $row->checked_out && ( $row->checked_out != $my->id )) {
					echo $row->Title;
				} else {
					?><a href="<?= $link ?>" title="Edit Content"><?= $row->Title ?></a><?php
				}
				?>
			</td>
			<td align="right">
				<?= $pageNav->orderUpIcon( $i ) ?>
			</td>
			<td align="left">
				<?= $pageNav->orderDownIcon( $i, $n ) ?>
			</td>
			<td align="center"><?= $row->Archived ?></td>
			<td align="center"><?= $row->Published ?></td>
		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	</table>
	<?php echo $pageNav->getListFooter(); ?>
	<input type="hidden" name="option" value="com_event" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="hidemainmenu" value="0" />
	</form><?php
}

function editEvent( $uid=0 ) {
	global $database, $my, $mainframe, $mosConfig_absolute_path, $mosConfig_live_site, $mosConfig_offset;
	
	$option = strval( mosGetParam( $_REQUEST, 'option', '' ) );
	
	// load the row from the db table
	$row = new mosEvent( $database );
	$row->load( (int)$uid );

	$selected_folders = NULL;
	if ( $uid == 0 ) {
		$row->Title = '';
		$row->Subtitle = '';
		$row->Intro = '';
		$row->Description = '';
		$row->LinkName = '';
		$row->Url = '';
		$row->Caption1 = '';
		$row->Caption2 = '';
		$row->Caption3 = '';
		$row->Url = 'http://';
		$row->Published = 'true';
	}

	mosMakeHtmlSafe( $row );

	mosCommonHTML::loadOverlib();
	mosCommonHTML::loadCalendar();
	?>
	<script language="javascript" type="text/javascript">
	<!--
	function submitbutton(pressbutton) {
		var form = document.adminForm;

		if (pressbutton == 'cancel') {
			submitform( pressbutton );
			return;
		}

		if (form.Title.value == ""){
			alert( "You Must enter a Title" );
		} else {
			<?php getEditorContents( 'editor1', 'Description' ) ; ?>
			submitform( pressbutton );
		}
	}
	//-->
	</script>
	<form enctype="multipart/form-data" action="index2.php" method="post" name="adminForm">
	<table class="adminheading">
		<tr><th class="edit"><?php echo $row->id ? 'Edit' : 'Add';?> Event</th></tr>
	</table>
	<table align="left" cellspacing="0" cellpadding="0" width="60%">
		<tr>
			<td width="60%" valign="top">
				<table width="100%" class="adminform">
					<tr>
						<td width="100%">
							<table cellspacing="0" cellpadding="0" border="0" width="100%">
								<tr><th colspan="4">Event Details</th></tr>
								<tr>
									<td>Published:</td>
									<td><input class="text_area" type="checkbox" name="Published"  value="true" <?= $row->Published == 'true' ? 'checked="checked"' : '' ?> /></td>
								</tr>
								<tr>
									<td>Archived:</td>
									<td><input class="text_area" type="checkbox" name="Archived"  value="true" <?= $row->Archived == 'true' ? 'checked="checked"' : '' ?> /></td>
								</tr>
								<tr>
									<td>Title:</td>
									<td><input class="text_area" type="text" name="Title" size="30" maxlength="100" value="<?= $row->Title ?>" /></td>
								</tr>
								<tr>
									<td>Subtitle:</td>
									<td><input class="text_area" type="text" name="Subtitle" size="30" maxlength="100" value="<?= $row->Subtitle ?>" /></td>
								</tr>
								<tr>
									<td valign="top" align="right">Start Date:</td>
									<td>
										<input class="text_area" type="text" name="StartDate" id="StartDate" size="25" maxlength="19" value="<?= $row->StartDate ?>" />
										<input name="reset" type="reset" class="button" onclick="return showCalendar('StartDate', 'y-mm-dd');" value="..." />
									</td>
								</tr>
								<tr>
									<td valign="top" align="right">End Date:</td>
									<td>
										<input class="text_area" type="text" name="EndDate" id="EndDate" size="25" maxlength="19" value="<?= $row->EndDate ?>" />
										<input name="reset" type="reset" class="button" onclick="return showCalendar('EndDate', 'y-mm-dd');" value="..." />
									</td>
								</tr>
								<tr>
									<td>Description:</td>
									<td><textarea name="Description" class="text_area" rows="15" cols="50"><?= $row->Description ?></textarea></td>
								</tr>
								<tr>
									<td>Link Name:</td>
									<td><input class="text_area" type="text" name="LinkName" size="30" maxlength="100" value="<?= $row->LinkName ?>" /></td>
								</tr>
								<tr>
									<td>Url:</td>
									<td><input class="text_area" type="text" name="Url" size="30" maxlength="100" value="<?= $row->Url ?>" /></td>
								</tr>
								<?= displayUploadFile( $row, "Photo1", "/data/event/images/", "image"  ) ?>
								<tr>
									<td>Caption 1:</td>
									<td><input class="text_area" type="text" name="Caption1" size="30" maxlength="100" value="<?= $row->Caption1 ?>" /></td>
								</tr>
								<tr>
									<td>Alt 1:</td>
									<td><input class="text_area" type="text" name="Alt1" size="30" maxlength="100" value="<?= $row->Alt1 ?>" /></td>
								</tr>
								<?= displayUploadFile( $row, "Photo2", "/data/event/images/", "image"  ) ?>
								<tr>
									<td>Caption 2:</td>
									<td><input class="text_area" type="text" name="Caption2" size="30" maxlength="100" value="<?= $row->Caption2 ?>" /></td>
								</tr>
								<tr>
									<td>Alt 2:</td>
									<td><input class="text_area" type="text" name="Alt2" size="30" maxlength="100" value="<?= $row->Alt2 ?>" /></td>
								</tr>
								<?= displayUploadFile( $row, "Photo3", "/data/event/images/", "image" ) ?>
								<tr>
									<td>Caption 3:</td>
									<td><input class="text_area" type="text" name="Caption3" size="30" maxlength="100" value="<?= $row->Caption3 ?>" /></td>
								</tr>
								<tr>
									<td>Alt 3:</td>
									<td><input class="text_area" type="text" name="Alt3" size="30" maxlength="100" value="<?= $row->Alt3 ?>" /></td>
								</tr>
								<tr>
									<td>Attach Photo Gallery:</td>
									<td><?
										$query = "SELECT * FROM #__gallery WHERE Published='true'";
										$database->setQuery( $query );
										$database->query();
										$ol = $database->loadObjectList();
									?>
										<select name="Gallery">
											<option value="">-- Select --</option><?
											createSelect( $ol, $row ); ?>
										</select>
									</td>
								</tr>
								<?= displayUploadFile( $row, "Document", "", "pdf" ) ?>
								<tr>
									<td>Document Link:</td>
									<td><input class="text_area" type="text" name="DocumentLink" size="30" value="<?= $row->DocumentLink ?>" /></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	<input type="hidden" name="id" value="<?= $row->id ?>" />
	<input type="hidden" name="option" value="com_event" />
	<input type="hidden" name="task" value="save" />
	</form><?php
}

function saveItem( $task ) {
	global $database, $my, $mainframe, $mosConfig_offset, $mosConfig_absolute_path;
	
	uploadFile2( "data/event/images", "Photo1");
	uploadFile2( "data/event/images", "Photo2");
	uploadFile2( "data/event/images", "Photo3");
	uploadFile2( "data/event/pdf", "Document", "Pdf");
	
	$row = new mosEvent( $database );
	if (!$row->bind( $_POST )) {
		echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
		exit();
	}
	// sanitise id field
	$row->id = (int) $row->id;

	// code cleaner for xhtml transitional compliance
	$row->Description = str_replace( '<br>', '<br />', $row->Description );

 	if (!$row->check()) {
		echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
		exit();
	}
	
	if( $row->id == 0 ) {
		$row->ordering = 0;
		$database->setQuery( "UPDATE #__event SET ordering=ordering+1" );
		$database->query();
	}
	
	$row->Published = strval( mosGetParam( $_REQUEST, 'Published', 'false' ) );
	$row->Archived = strval( mosGetParam( $_REQUEST, 'Archived', 'false' ) );

	$row->store();

	// clean any existing cache files
	mosCache::cleanCache( 'com_event' );
	switch ( $task ) {
		case 'apply':
			$msg = 'Successfully Saved changes to Item: '. $row->Title;
			mosRedirect( 'index2.php?option=com_event&task=edit&id='. $row->id, $msg );
			break;

		case 'save':
		default:
			mosRedirect( 'index2.php?option=com_event' );
			break;
	}
}

function removeItem( &$cid, $table ) {
	global $database;

	$total = count( $cid );
	if ( $total < 1) {
		echo "<script> alert('Select an item to delete'); window.history.go(-1);</script>\n";
		exit;
	}

	//seperate contentids
	mosArrayToInts( $cid );
	$cids = 'id=' . implode( ' OR id=', $cid );
	$query = "DELETE FROM #__".$table." WHERE ( $cids )";
	$database->setQuery( $query );
	if ( !$database->query() ) {
		echo "<script> alert('".$database->getErrorMsg()."'); window.history.go(-1); </script>\n";
		exit();
	}

	// clean any existing cache files
	mosCache::cleanCache( 'com_'.$table );

	$msg = $total ." Item(s) sent to the Trash";
	mosRedirect( 'index2.php?option=com_'.$table, $msg );
}

function order( $uid, $inc, $option ) {
	global $database;

	$row = new mosEvent( $database );
	$row->load( intval( $uid ) );
	
	$row->move( $inc );

	mosCache::cleanCache( 'com_event' );
	mosRedirect( 'index2.php?option='. $option );
}
/**************************************************************************************************************************/
/*                                                                                                                        */
/*								Helper Functions                                                                          */
/*                                                                                                                        */
/**************************************************************************************************************************/
function createSelect( $ObjectList, $row ) {
	foreach( $ObjectList as $x ) { ?>
		<option value="<?= $x->id ?>"<?= $row->Gallery == $x->id ? " selected='selected'" : "" ?>><?= $x->Name ?></option><?
	}
}
function formatTime( $time, $format ) {
	$strf = strftime( $format, strtotime( $time ) );
	if( strpos( $strf, "0" ) == 0 ) {
		$strf = substr( $strf, 1 );
	}
	return $strf;
}
?>