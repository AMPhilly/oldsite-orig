<?php
	$sql = "SELECT * FROM #__event WHERE id='".$id."'";
	$database->setQuery( $sql );
	$result = $database->loadObjectList();
	
	foreach( $result as $row ) { ?>
		<div class="content-item">
			<h1><?= $row->Title ?></h1>
			<?= etag( "h2", $row->Subtitle ) ?>
			<?php
				if( $row->StartDate != "0000-00-00" ) {
					$value = "<h3>".$row->StartDate;
					if( $row->EndDate != "0000-00-00" )
						$value .= " - ".$row->EndDate."</h3>";
					else
						$value .= "</h3>";
				}
				else if( $row->EndDate != "0000-00-00" )
					$value = "<h3>".$row->EndDate."</h3>";
				else
					$value = "";
				
				echo $value; ?>
			<?php
			if( $row->Photo1 != "" ) { ?>
			<div class="picture-box">
			<img src="../../data/event/images/<?= $row->Photo1 ?>" alt="<?= $row->Alt1 ?>" />
			<span><?= $row->Caption1 ?></span>
			
			</div><?
			} ?>
			
			<p><?= $row->Description ?></p>
			
			<p><?= displayLink( $row->Url, $row->LinkName ) ?></p>
			
			<p><?= displayDocument( "../../data/event/pdf/", $row->Document, $row->DocumentLink ) ?></p>
			
			<?php
			if( $row->Photo2 != "" ) { ?>
			<img src="../../data/news/images/<?= $row->Photo2 ?>" alt="<?= $row->Alt2 ?>" /><?
			} ?>
			
			<?php
			if( $row->Photo3 != "" ) { ?>
			<div class="picture-box">
			<img src="../../data/news/images/<?= $row->Photo3 ?>" alt="<?= $row->Alt3 ?>" />
			
			</div><?
			} ?>
		</div><?php
	}
	
	function etag( $tag, $data, $default="" ) {
		return $data != "" ? "<".$tag.">".$data."</".$tag.">" : $default;
	}
	
	function displayLink( $href, $link ) {
		if( $href == "" or strlen($href) < 8 )
			return "";
		
		if( $link == "" )
			$link = $href;
			
		return "<a href=\"".$href."\">".$link."</a>";
	}
	
	function displayDocument( $path, $file, $link ) {
		if( $file == "" )
			return "";
		
		return displayLink( $path.$file, $link );
	}
 ?>
	