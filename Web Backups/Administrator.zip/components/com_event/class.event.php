<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class mosEvent extends mosDBTable {
	var $id=null;
	
	var $Title=null;
	var $Subtitle=null;
	
	var $StartDate=null;
	var $EndDate=null;
	
	var $Description=null;
	
	var $LinkName=null;
	var $Url=null;
	
	var $Photo1=null;
	var $Caption1=null;
	var $Alt1=null;
	var $Photo2=null;
	var $Caption2=null;
	var $Alt2=null;
	var $Photo3=null;
	var $Caption3=null;
	var $Alt3=null;
	
	var $Gallery=null;
	var $Document=null;
	var $DocumentLink=null;
	
	var $Published=null;
	var $Archived=null;
	
	var $ordering=null;
	
	function mosEvent( &$db ) {
		$this->mosDBTable( '#__event', 'id', $db );
	}
	
	function schema() {
		return "CREATE TABLE IF NOT EXISTS `J_event` (
				`id` INT( 11 ) UNSIGNED NOT NULL AUTO_INCREMENT ,
				`Title` VARCHAR( 255 ) NOT NULL ,
				`Subtitle` VARCHAR( 255 ) NOT NULL ,
				`StartDate` DATE NULL ,
				`EndDate` DATE NULL ,
				`Description` TEXT NOT NULL ,
				`LinkName` VARCHAR( 255 ) NOT NULL ,
				`Url` VARCHAR( 255 ) NOT NULL ,
				`Photo1` VARCHAR( 255 ) NOT NULL ,
				`Caption1` VARCHAR( 255 ) NOT NULL ,
				`Alt1` VARCHAR( 255 ) NOT NULL ,
				`Photo2` VARCHAR( 255 ) NOT NULL ,
				`Caption2` VARCHAR( 255 ) NOT NULL ,
				`Alt2` VARCHAR( 255 ) NOT NULL ,
				`Photo3` VARCHAR( 255 ) NOT NULL ,
				`Caption3` VARCHAR( 255 ) NOT NULL ,
				`Alt3` VARCHAR( 255 ) NOT NULL ,
				`Gallery` INT( 11 ) NOT NULL ,
				`Document` VARCHAR( 255 ) NOT NULL ,
				`DocumentLink` VARCHAR( 255 ) NOT NULL ,
				`Archived` ENUM( 'false', 'true' ) NOT NULL DEFAULT 'false',
				`Published` ENUM( 'false', 'true' ) NOT NULL DEFAULT 'false',
				PRIMARY KEY ( `id` )
				) ENGINE = MYISAM";
	}
}
?>
