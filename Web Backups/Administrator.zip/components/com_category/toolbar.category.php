<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );

require_once( $mainframe->getPath( 'toolbar_html' ) );

switch ($task) {
	case 'viewLinks':
		TOOLBAR_links::_VIEWLINKS( );
		break;
	
	case 'newSection':
	case 'editSection':
		TOOLBAR_links::_EDITSECTION( );
		break;

	default:
		TOOLBAR_links::_DEFAULT();
		break;
}
?>