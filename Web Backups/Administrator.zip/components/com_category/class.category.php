<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class mosLinksSections extends mosDBTable {
	var $id=null;
	var $Title=null;
	var $Published=null;
	
	function mosLinksSections( &$db ) {
		$this->mosDBTable( '#__links_sections', 'id', $db );
	}
	
	function schema() {
		return " CREATE TABLE IF NOT EXISTS `J_links_sections` (
		`id` INT( 11 ) UNSIGNED NOT NULL AUTO_INCREMENT ,
		`Title` VARCHAR( 255 ) NOT NULL ,
		`Published` ENUM( 'false', 'true' ) NOT NULL DEFAULT 'false',
		PRIMARY KEY ( `id` )
		) ENGINE = MYISAM;";
	}
}
?>
