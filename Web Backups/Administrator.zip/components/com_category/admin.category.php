<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );
require_once("class.category.php");

$cid = josGetArrayInts( 'cid' );

switch ($task) {
	case 'newSection':
		editSection( 0 );
		break;

	case 'editSection':
		editSection( $id );
		break;

	case 'saveSection':
		saveSection();
		break;

	case 'remove':
		removeSection( $cid, 'links_sections' );
		break;

	default:
		viewSections();
		break;
}


// Section Functions
function viewSections() {
	global $database, $mainframe, $mosConfig_list_limit,  $my, $acl, $mosConfig_offset;
	
	$limit = intval( mosGetParam( $_REQUEST, 'limit', $mosConfig_list_limit ) );
	$limitstart = intval( mosGetParam( $_REQUEST, 'limitstart', 0 ) );

	// get the total number of records
	$query = "SELECT count(*) FROM #__links_sections";
	
	$database->setQuery( $query );
	$total = $database->loadResult();
	
	require_once( $GLOBALS['mosConfig_absolute_path'] . '/administrator/includes/pageNavigation.php' );
	$pageNav = new mosPageNav( $total, $limitstart, $limit );

	$query = "SELECT * FROM #__links_sections ORDER BY Title ASC";
	$database->setQuery( $query, $pageNav->limitstart, $pageNav->limit );
	$rows = $database->loadObjectList();

	if ($database->getErrorNum()) {
		echo $database->stderr();
		return false;
	}

	mosCommonHTML::loadOverlib();
	?>
	<form enctype="multipart/form-data" action="index2.php?option=com_category" method="post" name="adminForm">
		<table class="adminheading">
			<tr><th class="edit" rowspan="2" nowrap="nowrap">Manage Categories</th></tr>
		</table>
		<table class="adminlist">
			<tr>
				<th width="5">#</th>
				<th width="5"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $rows ); ?>);" /></th>
				<th class="title">Title</th>
				<th>Published</th>
			</tr>
		<?php
		$k = 0;
		$nullDate = $database->getNullDate();
		for ($i=0, $n=count( $rows ); $i < $n; $i++) {
			$row = &$rows[$i];
	
			mosMakeHtmlSafe($row);
	
			$link = 'index2.php?option=com_category&task=editSection&id='. $row->id;
			?>
			<tr class="<?= "row$k" ?>">
				<td><?= $pageNav->rowNumber( $i ) ?></td>
				<td align="center"><?php echo "<input type='checkbox' id='cb$i' name='cid[]' value='$row->id' onclick='isChecked(this.checked);' />"; ?></td>
				<td>
					<?php
					if ( $row->checked_out && ( $row->checked_out != $my->id )) {
						echo $row->Title;
					} else {
						?><a href="<?= $link ?>" title="Edit Content"><?= $row->Title ?></a><?php
					}
					?>
				</td>
				<td align="center"><?= $row->Published ?></td>
			</tr><?php
			$k = 1 - $k;
		}
		?>
		</table>
		<?php echo $pageNav->getListFooter(); ?>
		<input type="hidden" name="option" value="com_category" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="hidemainmenu" value="0" />
	</form>
	<?php
}

function editSection( $uid=0 ) {
	global $database, $my, $mainframe, $mosConfig_absolute_path, $mosConfig_live_site, $mosConfig_offset;

	// load the row from the db table
	$row = new mosLinksSections( $database );
	$row->load( (int)$uid );

	$selected_folders = NULL;
	if ( $uid == 0 ) {
		$row->Title = '';
		$row->Copy = '';
		$row->Published = 'true';
	}

	mosMakeHtmlSafe( $row );

	mosCommonHTML::loadOverlib();
	?>
	<script language="javascript" type="text/javascript">
	<!--
	function submitbutton(pressbutton) {
		var form = document.adminForm;

		if (pressbutton == 'cancel') {
			submitform( pressbutton );
			return;
		}

		// do field validation
		if (form.Title.value == ""){
			alert( "You Must enter a Title" );
		} else {
			submitform( pressbutton );
		}
	}
	//-->
	</script>
	<form enctype="multipart/form-data" action="index2.php" method="post" name="adminForm">
		<table class="adminheading">
			<tr><th class="edit"><?php echo $row->id ? 'Edit' : 'Add';?> Category</th></tr>
		</table>
		<table align="left" cellspacing="0" cellpadding="0" width="60%">
			<tr>
				<td width="60%" valign="top">
					<table width="100%" class="adminform">
						<tr>
							<td width="100%">
								<table cellspacing="0" cellpadding="0" border="0" width="100%">
									<tr>
										<th colspan="4">Category Details</th>
									</tr>
									<tr>
										<td>Published:</td>
										<td><input class="text_area" type="checkbox" name="Published" value="true" <?= $row->Published == 'true' ? 'checked="checked"' : '' ?> /></td>
									</tr>
									<tr>
										<td>Title:</td>
										<td><input class="text_area" type="text" name="Title" size="30" value="<?= $row->Title ?>" /></td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<input type="hidden" name="id" value="<?= $row->id ?>" />
		<input type="hidden" name="option" value="com_category" />
		<input type="hidden" name="task" value="saveSection" />
	</form>
	<?php
}

function saveSection() {
	global $database, $my, $mainframe, $mosConfig_offset, $mosConfig_absolute_path;
	
	$row = new mosLinksSections( $database );
	if (!$row->bind( $_POST )) {
		echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
		exit();
	}
	// sanitise id field
	$row->id = (int) $row->id;

	// code cleaner for xhtml transitional compliance
	
 	if (!$row->check()) {
		echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
		exit();
	}
	
	$row->Published = strval( mosGetParam( $_REQUEST, 'Published', 'false' ) );

	$row->store();

	// clean any existing cache files
	mosCache::cleanCache( 'com_category' );
	mosRedirect( 'index2.php?option=com_category' );
}

function removeSection( &$cid, $table ) {
	global $database;

	$total = count( $cid );
	if ( $total < 1) {
		echo "<script> alert('Select an item to delete'); window.history.go(-1);</script>\n";
		exit;
	}

	//seperate contentids
	mosArrayToInts( $cid );
	$cids = 'id=' . implode( ' OR id=', $cid );
	$query = "DELETE FROM #__".$table." WHERE ( $cids )";
	$database->setQuery( $query );
	if ( !$database->query() ) {
		echo "<script> alert('".$database->getErrorMsg()."'); window.history.go(-1); </script>\n";
		exit();
	}
	
	$cids = 'section_id=' . implode( ' OR section_id=', $cid );
	$query = "DELETE FROM #__linksSections WHERE ( $cids )";
	$database->setQuery( $query );
	if ( !$database->query() ) {
		echo "<script> alert('".$database->getErrorMsg()."'); window.history.go(-1); </script>\n";
		exit();
	}

	// clean any existing cache files
	mosCache::cleanCache( 'com_'.$table );

	$msg = $total ." Item(s) sent to the Trash";
	mosRedirect( 'index2.php?option=com_category', $msg );
}
?>