<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );
require_once("class.testimonial.php");

$cid = josGetArrayInts( 'cid' );

switch ($task) {
	case 'new':
		editTestimonial( 0 );
		break;

	case 'edit':
		editTestimonial( $id );
		break;

	case 'save':
		saveItem();
		break;

	case 'remove':
		removeItem( $cid );
		break;

	default:
		viewTestimonial();
		break;
}
/**************************************************************************************************************************/
/*                                                                                                                        */
/*								Testimonial Functions                                                                         */
/*                                                                                                                        */
/**************************************************************************************************************************/
function viewTestimonial() {
	global $database, $mainframe, $mosConfig_list_limit,  $my, $acl, $mosConfig_offset, $mosConfig_live_site;
	
	$limit = intval( mosGetParam( $_REQUEST, 'limit', $mosConfig_list_limit ) );
	$limitstart = intval( mosGetParam( $_REQUEST, 'limitstart', 0 ) );

	// get the total number of records
	$query = "SELECT count(*) FROM #__testimonial" . $where;
	
	$database->setQuery( $query );
	$total = $database->loadResult();
	
	require_once( $GLOBALS['mosConfig_absolute_path'] . '/administrator/includes/pageNavigation.php' );
	$pageNav = new mosPageNav( $total, $limitstart, $limit );

	$query = "SELECT * FROM #__testimonial" . $where . " ORDER BY ordering DESC";
	$database->setQuery( $query, $pageNav->limitstart, $pageNav->limit );
	$rows = $database->loadObjectList();

	if ($database->getErrorNum()) {
		echo $database->stderr();
		return false;
	}

	mosCommonHTML::loadOverlib();
	?>
	<form enctype="multipart/form-data" action="index2.php?option=com_testimonial" method="post" name="adminForm">
		<table class="adminheading">
			<tr><th class="edit" rowspan="2" nowrap="nowrap">Manage Testimonial</th></tr>
		</table>
		<table class="adminlist">
			<tr>
				<th width="5">#</th>
				<th width="5"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?= count( $rows ) ?>);" /></th>
				<th class="title">Name</th>
				<th>Published</th>
			</tr>
		<?php
		$k = 0;
		$nullDate = $database->getNullDate();
		for ($i=0, $n=count( $rows ); $i < $n; $i++) {
			$row = &$rows[$i];
	
			mosMakeHtmlSafe($row);
	
			$link 	= 'index2.php?option=com_testimonial&task=edit&id='. $row->id;
	
			$access 	= mosCommonHTML::AccessProcessing( $row, $i );
			$checked 	= mosCommonHTML::CheckedOutProcessing( $row, $i );
			?>
			<tr class="<?= "row$k" ?>">
				<td><?= $pageNav->rowNumber( $i ) ?></td>
				<td align="center"><?= "<input type='checkbox' id='cb$i' name='cid[]' value='$row->id' onclick='isChecked(this.checked);' />" ?></td>
				<td>
				<?php
					if ( $row->checked_out && ( $row->checked_out != $my->id )) {
						echo $row->Name;
					} else { ?>
					<a href="<?= $link ?>"><?= $row->Title ?></a>
				<? } ?>
				</td>
				<td align="center"><?= $row->Published ?></td>
			</tr><?
			$k = 1 - $k;
		} ?>
		</table>
		<?= $pageNav->getListFooter() ?>
		<input type="hidden" name="option" value="com_testimonial" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="hidemainmenu" value="0" />
	</form>
<?
}
function editTestimonial( $uid=0 ) {
	global $database, $my, $mainframe, $mosConfig_absolute_path, $mosConfig_live_site, $mosConfig_offset;

	// load the row from the db table
	$row = new mosTestimonial( $database );
	$row->load( (int)$uid );

	if ( $uid == 0 ) {
		$row->Published = 'true';
	}

	mosMakeHtmlSafe( $row );

	mosCommonHTML::loadOverlib();
?>
	<script language="javascript" type="text/javascript">
	<!--
	function submitbutton(pressbutton) {
		var form = document.adminForm;

		if (pressbutton == 'cancel') {
			submitform( pressbutton );
			return;
		}
		// do field validation
		if (form.Title.value == "") {
			alert( "You Must enter a Title" );
		} else {
			submitform( pressbutton );
		}
	}
	//-->
	</script>
	<form enctype="multipart/form-data" action="index2.php" method="post" name="adminForm">
		<table class="adminheading">
			<tr>
				<th class="edit"><?= $row->id ? 'Edit' : 'New' ?> Testimonial</th>
			</tr>
		</table>
		<table align="left" cellspacing="0" cellpadding="0" width="60%">
			<tr>
				<td width="60%" valign="top">
					<table width="100%" class="adminform">
						<tr>
							<td width="100%">
								<table cellspacing="0" cellpadding="0" border="0" width="100%">
									<tr><th colspan="4">Item Details</th></tr>
									<tr>
										<td>Published:</td>
										<td align="left"><input class="text_area" type="checkbox" name="Published"  value="true" <?= $row->Published == 'true' ? 'checked="checked"' : '' ?> /></td>
									</tr>
									<tr>
										<td>Title:</td>
										<td><input class="text_area" type="text" name="Title" size="30" maxlength="100" value="<?= $row->Title ?>" /></td>
									</tr>
									<tr>
										<td>Author:</td>
										<td><input class="text_area" type="text" name="Author" size="30" maxlength="100" value="<?= $row->Author ?>" /></td>
									</tr>
									<tr>
										<td>Location:</td>
										<td><input class="text_area" type="text" name="Location" size="30" maxlength="255" value="<?= $row->Location ?>" /></td>
									</tr>
									<tr>
										<td valign="top" align="right">Testimonial:</td>
										<td>
											<textarea class="text_area" name="Copy" rows="10" cols="50" /><?= $row->Copy ?></textarea>
										</td>
									</tr>
									<input type="hidden" name="Section" value="0" />
									<?= displayUploadFile( $row, "Photo", "/data/testimonial/images/", "image"  ) ?>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<input type="hidden" name="id" value="<?= $row->id ?>" />
		<input type="hidden" name="option" value="com_testimonial" />
		<input type="hidden" name="task" value="save" />
	</form>
<?
}
function saveItem() {
	global $database, $my, $mainframe, $mosConfig_offset, $mosConfig_absolute_path;
	
	uploadFile2( "data/testimonial/images", "Photo");
	
	$row = new mosTestimonial( $database );
	if (!$row->bind( $_POST )) {
		echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
		exit();
	}
	// sanitise id field
	$row->id = (int) $row->id;

 	if (!$row->check()) {
		echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
		exit();
	}
	
	//$row->Section = implode( ";", $row->Section );
	
	$row->Published = strval( mosGetParam( $_REQUEST, 'Published', 'false' ) );

	$row->store();

	// clean any existing cache files
	mosCache::cleanCache( 'com_testimonial' );
	mosRedirect( 'index2.php?option=com_testimonial' );
}
function removeItem( &$cid ) {
	global $database;

	$total = count( $cid );
	if ( $total < 1) {
		echo "<script> alert('Select an item to delete'); window.history.go(-1);</script>\n";
		exit;
	}

	//seperate contentids
	mosArrayToInts( $cid );
	$cids = 'id=' . implode( ' OR id=', $cid );
	$query = "DELETE FROM #__testimonial WHERE ( $cids )";
	$database->setQuery( $query );
	if ( !$database->query() ) {
		echo "<script> alert('".$database->getErrorMsg()."'); window.history.go(-1); </script>\n";
		exit();
	}

	mosCache::cleanCache( 'com_testimonial' );

	$msg 	= $total ." Item(s) sent to the Trash";
	mosRedirect( 'index2.php?option=com_testimonial', $msg );
}
?>