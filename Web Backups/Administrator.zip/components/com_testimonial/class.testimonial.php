<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class mosTestimonial extends mosDBTable {
	var $id=null;
	var $Section=null;
	var $Title=null;
	var $Author=null;
	var $Location=null;
	var $Copy=null;
	var $Photo=null;
	var $Published=null;
	var $ordering=null;
	
	function mosTestimonial( &$db ) {
		$this->mosDBTable( '#__testimonial', 'id', $db );
	}
	
	function schema() {
		return "CREATE TABLE IF NOT EXISTS `J_testimonial` (
		`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
		`Section` INT(11) UNSIGNED NOT NULL,
		`Title` VARCHAR(255) NOT NULL,
		`Author` VARCHAR(255) NOT NULL,
		`Copy` TEXT NOT NULL,
		`Photo` TEXT NOT NULL,
		`Published` ENUM('false', 'true') NOT NULL DEFAULT 'false',
		`ordering` INT(11) NOT NULL,
		PRIMARY KEY (`id`),
		INDEX (`Section`)
		) ENGINE = MYISAM;";
	}
}
?>
