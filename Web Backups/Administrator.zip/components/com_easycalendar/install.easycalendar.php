<?php
/**
* @package Easy Calendar
* @copyright (C) 2006 Joomla-addons.org
* @author Websmurf
* 
* --------------------------------------------------------------------------------
* All rights reserved.  Easy Calender Component for Joomla!
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the Creative Commons - Attribution-NoDerivs 2.5 
* license as published by the Creative Commons Organisation
* http://creativecommons.org/licenses/by-nd/2.5/.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
* --------------------------------------------------------------------------------
**/

defined( '_VALID_MOS' ) or die( 'Restricted access' );

function com_install(){
  global $mainframe, $database;
  
  //Updates menu option
  $query = "UPDATE #__components 
    SET admin_menu_img='../administrator/components/com_easycalendar/icons/16x16_date.png' 
    WHERE admin_menu_link='option=com_easycalendar'";
  $database->setQuery($query);
  if(!$database->query()){  
    echo $database->getErrorMsg() . '<br />';
  }
  
  //Updates menu option
  $query = "UPDATE #__components 
    SET admin_menu_img='js/ThemeOffice/categories.png' 
    WHERE admin_menu_link='option=com_easygallery&act=categories'";
  $database->setQuery($query);
  if(!$database->query()){  
    echo $database->getErrorMsg() . '<br />';
  }
  
  //Updates menu option
  $query = "UPDATE #__components 
    SET admin_menu_img='../administrator/components/com_easycalendar/icons/16x16_date.png' 
    WHERE admin_menu_link='option=com_easycalendar&act=events'";
  $database->setQuery($query);
  if(!$database->query()){  
    echo $database->getErrorMsg() . '<br />';
  }
  
  //update menu
  $query = "SELECT id FROM #__components WHERE link = 'option=com_easycalendar'";
  $database->setQuery($query);
  $id = $database->loadResult();
  echo $database->getErrorMsg();
  
  $query = "UPDATE #__menu SET componentid = $id WHERE type = 'components' AND link='index.php?option=com_easycalendar'";
  $database->setQuery($query);
  if(!$database->query()){
    $database->getErrorMsg();
  }
}

?>