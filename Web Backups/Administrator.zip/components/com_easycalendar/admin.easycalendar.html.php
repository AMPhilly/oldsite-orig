<?php
/**
* @package EasyGallery
* @copyright (C) 2006 Joomla-addons.org
* @author Websmurf
* 
* --------------------------------------------------------------------------------
* All rights reserved.  Easy Gallery Component for Joomla!
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the Creative Commons - Attribution-NoDerivs 2.5 
* license as published by the Creative Commons Organisation
* http://creativecommons.org/licenses/by-nd/2.5/.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
* --------------------------------------------------------------------------------
**/

defined( '_VALID_MOS' ) or die( 'Restricted access' );

class HTML_easycalendar {
  
  /**
   * Display a list of all categories
   *
   * @param array $rows
   * @param <var>mosPageNav</var> $pageNav
   * @param array $lists
   */
  function showCategories($rows, $pageNav, $lists){
    global $option;
    ?>
    <form action="index2.php" method="post" name="adminForm">
		<table class="adminheading">
		<tr>
		  <th class="categories">Category Manager</th>
		  <td nowrap="nowrap">Category: <?php echo $lists['cid']; ?></td>
	  </tr>
	  </table>
	  <table class="adminlist">
		<tr>
			<th width="10" align="left">#</th>
			<th width="20"><input type="checkbox" name="toggle" value="" onClick="checkAll(<?php echo count( $rows );?>);" /></th>
			<th class="title">Category Name</th>
			<th width="10%">Published</th>
			<th colspan="2" width="5%">Reorder</th>
			<th width="2%">Order</th>
			<th width="1%"><a href="javascript: saveorder( <?php echo count( $rows )-1; ?> )"><img src="images/filesave.png" border="0" width="16" height="16" alt="Save Order" /></a></th>
			<th width="5%" nowrap>Category ID</th>
			<th width="20%"></th>
		</tr>
		<?php
		$k = 0;
		for ($i=0, $n=count( $rows ); $i < $n; $i++) {
			$row 	= &$rows[$i];

			$link = 'index2.php?option='. $option . '&act=categories&task=edit&hidemainmenu=1&cid='. $row->id;

			$checked 	= mosCommonHTML::CheckedOutProcessing( $row, $i );
			$published 	= mosCommonHTML::PublishedProcessing( $row, $i );
			?>
			<tr class="<?php echo "row$k"; ?>">
				<td><?php echo $pageNav->rowNumber( $i ); ?></td>
				<td><?php echo $checked; ?></td>
				<td>
				  <a href="<?php echo $link; ?>">
				  <?php echo stripslashes( $row->name ) .' ( '. stripslashes( $row->title ) .' )'; ?>
				  </a>
				</td>
				<td align="center"><?php echo $published;?></td>
				<td><?php echo $pageNav->orderUpIcon( $i ); ?></td>
				<td><?php echo $pageNav->orderDownIcon( $i, $n ); ?></td>
				<td align="center" colspan="2"><input type="text" name="order[]" size="5" value="<?php echo $row->ordering; ?>" class="text_area" style="text-align: center" /></td>
				<td align="center"><?php echo $row->id; ?></td>
				<td></td>				
				<?php
				$k = 1 - $k;
				?>
			</tr>
			<?php
		}
		?>
		</table>

		<?php echo $pageNav->getListFooter(); ?>

		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="act" value="categories" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="hidemainmenu" value="0" />
		</form>
    <?php
  }
  
  /**
	* Edit or add a category
	* @param mosCategory The category object
	* @param string
	*/
	function editCategory( $row, $lists ) {
	  global $option;
		?>
		<script language="javascript" type="text/javascript">
		function submitbutton(pressbutton, section) {
			var form = document.adminForm;
			if (pressbutton == 'cancel') {
				submitform( pressbutton );
				return;
			}

			if ( form.name.value == "" ) {
				alert("Category must have a name");
			} else {
				submitform(pressbutton);
			}
		}
		</script>

		<form action="index2.php" method="post" name="adminForm">
		<table class="adminheading">
		<tr>
			<th class="categories"><?php echo $row->id ? 'Edit a category' : 'Add a category';?></th>
		</tr>
		</table>

		<table class="adminform">
		<tr>
			<th colspan="3">Category Details</th>
		<tr>
		<tr>
			<td width="150">Category Title:</td>
			<td colspan="2"><input class="text_area" type="text" name="title" value="<?php echo stripslashes( $row->title ); ?>" size="50" maxlength="50" title="A short name to appear in menus" /></td>
		</tr>
		<tr>
			<td>Category Name:</td>
			<td colspan="2"><input class="text_area" type="text" name="name" value="<?php echo stripslashes( $row->name ); ?>" size="50" maxlength="255" title="A long name to be displayed in headings" /></td>
		</tr>
		<tr valign="top">
			<td>
			Access Level:
			</td>
			<td>
			<?php echo $lists['access']; ?>
			</td>
		</tr>
		<tr>
			<td>Parent:</td>
			<td><?php echo $lists['parent_id']; ?></td>
		</tr>
		<tr>
			<td>Published:</td>
			<td><?php echo $lists['published']; ?></td>
		</tr>
		<tr>
			<td valign="top" colspan="2">Description:</td>
		</tr>
		<tr>
			<td colspan="3">
				<textarea class="text_area" name="description" rows="10" cols="50" /><?= $row->description ?></textarea>
			</td>
		</tr>
		</table>

		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="act" value="categories" />
		<input type="hidden" name="id" value="<?php echo $row->id; ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="hidemainmenu" value="0" />
		</form>
		<?php
	}
	
	/**
   * Display a list of all events
   *
   * @param array $rows
   * @param <var>mosPageNav</var> $pageNav
   * @param array $lists
   */
  function showEvents($rows, $pageNav, $lists){
    global $option;
    ?>
    <form action="index2.php" method="post" name="adminForm">
		<table class="adminheading">
		<tr>
		  <th class="edit">Events Manager</th>
		  <td nowrap="nowrap">Category: <?php echo $lists['cid']; ?></td>
	  </tr>
	  </table>
	  <table class="adminlist">
		<tr>
			<th width="10" align="left">#</th>
			<th width="20"><input type="checkbox" name="toggle" value="" onClick="checkAll(<?php echo count( $rows );?>);" /></th>
			<th class="title">Name</th>
			<th class="title">Category</th>
			<th class="title">Start</th>
			<th class="title">End</th>
			<th width="25">Published</th>
		</tr>
		<?php
		$k = 0;
		for ($i=0, $n=count( $rows ); $i < $n; $i++) {
			$row 	= &$rows[$i];

			$link = 'index2.php?option='. $option . '&act=events&task=edit&hidemainmenu=1&cid='. $row->id;

			$published 	= mosCommonHTML::PublishedProcessing( $row, $i );
			?>
			<tr class="<?php echo "row$k"; ?>">
				<td><?php echo $pageNav->rowNumber( $i ); ?></td>
				<td><?php echo mosHTML::idBox($i, $row->id); ?></td>
				<td>
				  <a href="<?php echo $link; ?>">
				  <?php echo $row->name; ?>
				  </a>
				</td>
				<td><?php echo $row->category;?></td>
				<td><?php echo $row->startdate . ' ' . date("h:i A", strtotime($row->starttime));?></td>
				<td><?php echo $row->enddate . ' ' . date("h:i A", strtotime($row->endtime));?></td>
				<td align="center"><?php echo $published;?></td>
				<?php
				$k = 1 - $k;
				?>
			</tr>
			<?php
		}
		?>
		</table>

		<?php echo $pageNav->getListFooter(); ?>

		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="act" value="events" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="hidemainmenu" value="0" />
		</form>
    <?php
  }
  
  /**
	* Edit or add an event
	* @param dbEvent Event
	* @param array
	*/
	function editEvent( $row, $lists ) {
	  global $option;
	  
	  mosCommonHTML::loadCalendar();
	  mosCommonHTML::loadOverlib();
		?>
		<script language="javascript" type="text/javascript">
		<!--
		function submitbutton(pressbutton) {
			var form = document.adminForm;
			if (pressbutton == 'cancel') {
				submitform( pressbutton );
				return;
			}

			if ( form.name.value == "" ) {
				alert("Event must have a name");
				return;
			} 
			if ( form.startdate.value == "" ) {
				alert("Event must have a startdate");
				return;
			}
			if( form.enddate.value == ""){
			  form.enddate.value = form.startdate.value;
			}
			
			if(form.enddate.value == form.startdate.value){
			  if(form.starttime.selectedIndex > form.endtime.selectedIndex){
			    alert("Starttime must be later then endtime");
			    return;
			  }
			}
			
			submitform(pressbutton);
		}
		-->
		</script>

		<form action="index2.php" method="post" name="adminForm">
		<table class="adminheading">
		<tr>
			<th class="edit"><?php echo $row->id ? 'Edit an event' : 'Add an event';?></th>
		</tr>
		</table>
		
		<table>
		<tr valign="top">
		  <td width="60%">
    		<table class="adminform">
    		<tr>
    			<th class="title" colspan="2">Event Details</th>
    		<tr>
    		<tr>
    			<td width="150">Name:</td>
    			<td><input class="text_area" type="text" name="name" value="<?php echo $row->name; ?>" size="50" maxlength="255" title="A short name to appear in menus" /></td>
    		</tr>
    		<tr>
    		  <td>Category</td>
    		  <td><?php echo $lists['cid']; ?></td>
    		</tr>
    		<tr>
    			<td valign="top">Description:</td>
    			<td>
    				<textarea class="text_area" name="description" rows="10" cols="50" /><?= $row->description ?></textarea>
    			</td>
    		</tr>
    		<tr>
    			<td>Published:</td>
    			<td><?php echo $lists['published']; ?></td>
    		</tr>
    		</table>
      </td>
      <td>
        <table class="adminform">
        <tr>
    			<th class="title" colspan="2">Event Properties</th>
    		<tr>
        <tr>
          <td width="100">Start date:</td>
          <td>
            <input class="text_area" type="text" name="startdate" id="startdate" size="25" maxlength="19" value="<?php echo $row->startdate; ?>" />
					  <input name="reset" type="reset" class="button" onclick="return showCalendar('startdate', 'y-mm-dd');" value="..." />
					</td>
        </tr>
        <tr>
          <td>Start time:</td>
          <td><?php echo $lists['starttime']; ?></td>
        </tr>
        <tr>
          <td width="100">End date:</td>
          <td>
            <input class="text_area" type="text" name="enddate" id="enddate" size="25" maxlength="19" value="<?php echo $row->enddate; ?>" />
					  <input name="reset" type="reset" class="button" onclick="return showCalendar('enddate', 'y-mm-dd');" value="..." />
					</td>
        </tr>
        <tr>
          <td>End time:</td>
          <td><?php echo $lists['endtime']; ?></td>
        </tr>
        </table>
      </td>
		</tr>
		</table>
		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="act" value="events" />
		<input type="hidden" name="id" value="<?php echo $row->id; ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="hidemainmenu" value="0" />
		</form>
		<?php
	}
	
	
	function showCredits()
	{
		global $option, $easycalendar_version; ?>
	
		<table class="adminheading">
			<tr><th class="cpanel" rowspan="2" nowrap>Manage Calendar</th></tr>
		</table>
		<table cellpadding="4" cellspacing="0" border="0" width="400" class="adminform">
			<tr valign="top">
				<td width="380">
					<div id="cpanel">
						<div style="float:left;">
							<div class="icon">
								<a href="index2.php?option=com_easycalendar&act=categories">
									<div class="iconimage"><img src="images/categories.png" alt="Manage categories" align="middle" name="image" border="0" /></div>
									Manage Categories
								</a>
							</div>
						</div>
						<div style="float:left;">
							<div class="icon">
								<a href="index2.php?option=com_easycalendar&act=events">
									<div class="iconimage"><img src="components/com_easycalendar/icons/48x48_date.png" alt="Manage Events" align="middle" name="image" border="0" /></div>
									Manage Events</a>
							</div>
						</div>
					</div>
				</td>
			</tr>
		</table><?php
	}
  
	function showConfiguration()
	{
		echo "configuration";
	}
}