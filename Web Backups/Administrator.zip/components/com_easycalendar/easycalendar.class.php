<?php
/**
* @package Easy Calendar
* @copyright (C) 2006 Joomla-addons.org
* @author Websmurf
* 
* --------------------------------------------------------------------------------
* All rights reserved.  Easy Calendar Component for Joomla!
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the Creative Commons - Attribution-NoDerivs 2.5 
* license as published by the Creative Commons Organisation
* http://creativecommons.org/licenses/by-nd/2.5/.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
* --------------------------------------------------------------------------------
**/

defined( '_VALID_MOS' ) or die( 'Restricted access' );

$easycalendar_version = '1.0 beta 1';

require_once($mainframe->getCfg('absolute_path') . '/administrator/components/com_easycalendar/classes/categories.php');
require_once($mainframe->getCfg('absolute_path') . '/administrator/components/com_easycalendar/classes/events.php');

class dbEvent extends mosDBTable {
  /** @var int ID **/
  var $id = null;
  /** @var int category ID **/
  var $cid = null;
  /** @var date date **/
  var $startdate = null;
  /** @var date date **/
  var $enddate = null;
  /** @var time start **/
  var $starttime = null;
  /** @var time end **/
  var $endtime = null;
  /** @var string name **/
  var $name = null;
  /** @var text description **/
  var $description = null;
  /** @var boolean published **/
  var $published = null;
  
  function dbEvent(&$db){
    $this->mosDBTable('#__easycalendar', 'id', $db);
  }
}


?>