<?php
/**
* @package Easy Calendar
* @copyright (C) 2006 Joomla-addons.org
* @author Websmurf
* 
* --------------------------------------------------------------------------------
* All rights reserved.  Easy Calendar Component for Joomla!
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the Creative Commons - Attribution-NoDerivs 2.5 
* license as published by the Creative Commons Organisation
* http://creativecommons.org/licenses/by-nd/2.5/.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
* --------------------------------------------------------------------------------
**/

defined( '_VALID_MOS' ) or die( 'Restricted access' );


class events {
  
  /**
   * Show a list of all events
   *
   */
  function show(){
    global $database, $mainframe, $option;
    
    $limit = intval( $mainframe->getUserStateFromRequest( "viewlistlimit", 'limit', $mainframe->getCfg('list_limit') ) );
  	$limitstart	= intval( $mainframe->getUserStateFromRequest( "view{$option}limitstart", 'limitstart', 0 ) );
  	$cid	= intval( $mainframe->getUserStateFromRequest( "view{$option}cid", 'cid', 0 ) );
  	$search	= $mainframe->getUserStateFromRequest( "search{$option}", 'search', '' );
  	$search	= $database->getEscaped( trim( strtolower( $search ) ) );
  	
  	$where = array();
  	if(!empty($search)){
  	  $where[] = "name LIKE '%" . $search . "%'";
  	}
  	if($cid > 0){
  	  $where[] = 'cid = ' . $cid;
  	}
  	
  	$basequery = "SELECT %s FROM #__easycalendar e
  	  LEFT JOIN #__categories c ON e.cid = c.id ";
  	if(sizeof($where) > 0){
  	  $basequery .= "WHERE " . implode(" AND ", $where);
  	}
  	$basequery .= " ORDER BY name";
  	
  	$query = str_replace('%s', 'COUNT(1)', $basequery);
  	$database->setQuery($query);
  	$total = $database->loadResult();
  	
  	require_once($mainframe->getCfg('absolute_path') . '/administrator/includes/pageNavigation.php');
  	$pageNav = new mosPageNav($total, $limitstart, $limit);
  	
  	$query = str_replace("%s", "e.*, c.name AS category", $basequery);
  	$database->setQuery($query);
  	$rows = $database->loadObjectList();
  	echo $database->getErrorMsg();
  	
  	$lists = array();
  	$lists['search'] = $search;
  	
  	$categories = categories::getCategorieTree();
  	
  	$obj = new stdClass();
  	$obj->id = 0;
  	$obj->name = ' - all - ';
  	
  	array_unshift($categories, $obj);
  	
  	$lists['cid'] = mosHTML::selectList($categories, 'cid', 'onchange="document.adminForm.submit();"', 'id', 'name', $cid);
  	
  	HTML_easycalendar::showEvents($rows, $pageNav, $lists);
  }
  
  /**
   * Edit an event
   *
   * @param int $id
   */
  function edit($id){
    global $database;
    
    $row = new dbEvent($database);
    $row->load($id);
    
    $lists = array();
    
    $categories = categories::getCategorieTree();
  	
  	$obj = new stdClass();
  	$obj->id = 0;
  	$obj->name = ' - select - ';
  	
  	array_unshift($categories, $obj);
  	
  	$lists['cid'] = mosHTML::selectList($categories, 'cid', 'class="text_area"', 'id', 'name', $row->cid);
  	$lists['published'] = mosHTML::yesnoRadioList('published', '', intval($row->published));
  	
  	$times = array();
  	for($i=0;$i<24;$i++){
  	  $times[] = mosHTML::makeOption((strlen($i) < 2 ? '0'.$i : $i) . ':00:00', date("h:i A", strtotime($i.':00')));
	  $times[] = mosHTML::makeOption((strlen($i) < 2 ? '0'.$i : $i) . ':15:00', date("h:i A", strtotime($i.':15')));
  	  $times[] = mosHTML::makeOption((strlen($i) < 2 ? '0'.$i : $i) . ':30:00', date("h:i A", strtotime($i.':30')));
	  $times[] = mosHTML::makeOption((strlen($i) < 2 ? '0'.$i : $i) . ':45:00', date("h:i A", strtotime($i.':45')));
  	}
  	
  	$lists['starttime'] = mosHTML::selectList($times, 'starttime', 'class="text_area"', 'value', 'text', $row->starttime);
  	$lists['endtime'] = mosHTML::selectList($times, 'endtime', 'class="text_area"', 'value', 'text', $row->endtime);
    
    HTML_easycalendar::editEvent($row, $lists);
  }
  
  /**
   * Save event
   *
   */
  function save(){
    global $database, $option, $task;
    
    $row = new dbEvent($database);
    $row->bind($_POST);
    
    if (!$row->check()) {
			echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
			exit();
		}
		if (!$row->store()) {
			echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
			exit();
		}
		
		switch ($task){
		  case 'save':
		    mosRedirect('index2.php?option=' . $option . '&act=events', 'Changes to event saved');
		    break;
		  case 'apply':
		    mosRedirect('index2.php?option=' . $option . '&act=events&task=edit&cid=' . $row->id . '&hidemainmenu=1', 'Changes to event saved');
		    break;
		}
  }
  
  /**
   * Remove Event(s)
   *
   * @param array ids
   */
  function remove($cid){
    global $database, $option;
    
    $row = new dbEvent($database);
    
    for($i=0,$n=count($cid);$i<$n;$i++){
      $id = $cid[$i];
      
      $row->delete($id);
    }
    
    mosRedirect('index2.php?option=' . $option . '&act=events', 'Selected events removed');
  }
  
  /**
   * Set a Event state
   *
   * @param int id
   * @param int published
   */
  function setState($ids, $published){
    global $database, $option;
    
    $row = new dbEvent($database);
    for($i=0,$n=count($ids);$i<$n;$i++){
      $row->load($ids[$i]);
    
      $row->published = $published;
    
      if (!$row->store()) {
  			echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
  			exit();
  		}
    }
    
    mosRedirect('index2.php?option=' . $option . '&act=events');
  }
  
  /**
   * Display all items in the frontend
   *
   * @param int category id
   * @param mosParameters params
   */
  function frontView($cid, $view, $params){
    global $database;
    
    $month = intval(mosGetParam($_REQUEST, 'month', date('m')));
    $year = intval(mosGetParam($_REQUEST, 'year', date('Y')));
    
    $rows = events::getEvents($cid, $view);

//    echo '<pre>';
//    print_r($rows);
//    echo '</pre>';
    
    switch ($view){
      case 'upcoming':
        HTML_easycalendar::showUpcoming($rows);
        break;
      case 'month':
      default:
        HTML_easycalendar::showMonth($rows, $month, $year);
        break;
    }
  }
  
  /**
   * Get all events from a certain category and display them accoording to a certain view
   *
   * @param int $cid
   * @param string $view
   * @return array
   */
  function getEvents($cid, $view){
    global $database;
    
    $where = array();
    $where[] = 'e.published = 1 AND c.published = 1';
    if($cid > 0){
      /** @todo get subcategories and show them as well **/
      $where[] = 'cid = ' . $cid;
    }
    switch ($view){
      case 'upcoming':
        $where[] = '
        (
          ( 
            DATE(startdate) >= DATE(NOW()) OR 
            DATE(enddate) >= DATE(NOW()) 
          ) AND
          (
            DATE(startdate) <= DATE(DATE_ADD(NOW(), INTERVAL 1 MONTH)) OR 
            DATE(enddate) <= DATE(DATE_ADD(NOW(), INTERVAL 1 MONTH))
          )
        )';
        break;
      case 'month':
      default:
        $month = intval(mosGetParam($_REQUEST, 'month', date('m')));
        $year = intval(mosGetParam($_REQUEST, 'year', date('Y')));
        
        $where[] = '((MONTH(startdate) = ' . $month . ' AND YEAR(startdate) = ' . $year . ') OR (MONTH(enddate) = ' . $month . ' AND YEAR(enddate) = ' . $year . '))';
    }
    
    $query = 'SELECT e.*, c.name AS category FROM #__easycalendar e ' . "\n";
    $query .= 'LEFT JOIN #__categories c ON e.cid = c.id ';
    if(sizeof($where) > 0){
      $query .= 'WHERE ' . implode(' AND ', $where) . "\n";
    }
    $query .= 'ORDER BY startdate, starttime';
    
    $database->setQuery($query);
    $rows = $database->loadObjectList();
//    echo $database->getQuery();
    echo $database->getErrorMsg();
    
    $array = array();
    for($i=0,$n=count($rows);$i<$n;$i++){
      $row = $rows[$i];
      switch ($view){
        case 'upcoming':
          $array[] = $row;
          break;
        case 'month':
        default:
          if($row->startdate == $row->enddate){ //nothing special
            if($row->starttime == $row->endtime){
              $array[$row->startdate]['allday'][] = $row;
            } else {
              $array[$row->startdate]['regular'][] = $row;
            }
          }
          else {
            //meerdere dagen
            $start = strtotime($row->startdate . ' 12:00:00');
            $end = strtotime($row->enddate . ' 12:00:00');

            for($j=$start;$j<$end + (60*60*24);$j=$j+(60*60*24)){
              $array[date('Y-m-d', $j)]['allday'][] = $row;
            }
          }
      }
    }
    
    return $array;
  }
 
  /**
   * View details of a certain event
   *
   * @param int $id
   */
  function view($id, $params){
    global $database;
    
    $row = new dbEvent($database);
    $row->load($id);
    
    $row->category = new mosCategory($database);
    $row->category->load($row->cid);
    
    HTML_easycalendar::viewEvent($row, $params);
  }
}

?>