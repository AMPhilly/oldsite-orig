<?php
/**
* @package Easy Calendar
* @copyright (C) 2006 Joomla-addons.org
* @author Websmurf
* 
* --------------------------------------------------------------------------------
* All rights reserved.  Easy Calendar Component for Joomla!
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the Creative Commons - Attribution-NoDerivs 2.5 
* license as published by the Creative Commons Organisation
* http://creativecommons.org/licenses/by-nd/2.5/.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
* --------------------------------------------------------------------------------
**/

defined( '_VALID_MOS' ) or die( 'Restricted access' );


class categories {
  
  /**
   * Show all categories
   *
   */
  function show(){
    global $database, $mainframe, $option;
    
  	$limit = intval( $mainframe->getUserStateFromRequest( "viewlistlimit", 'limit', $mainframe->getCfg('list_limit') ) );
  	$limitstart	= intval( $mainframe->getUserStateFromRequest( "view{$option}limitstart", 'limitstart', 0 ) );
  	$cid	= intval( $mainframe->getUserStateFromRequest( "view{$option}cid", 'cid', 0 ) );
  	$search	= $mainframe->getUserStateFromRequest( "search{$option}", 'search', '' );
  	$search	= $database->getEscaped( trim( strtolower( $search ) ) );
  	
  	$where = array();
  	$where[] = "section = 'com_easycalendar'";
  	if(!empty($search)){
  	  $where[] = "c.title LIKE '%" . $search . "%'";
  	}
  	if($cid > 0){
  	  $where[] = 'c.parent_id = ' . $cid;
  	}
  	
  	$basequery = "SELECT %s FROM #__categories c ";
  	if(sizeof($where) > 0){
  	  $basequery .= "WHERE " . implode(" AND ", $where);
  	}
  	$basequery .= " ORDER BY parent_id, ordering";
  	
  	$query = str_replace('%s', 'COUNT(1)', $basequery);
  	$database->setQuery($query);
  	$total = $database->loadResult();
  	
  	require_once($mainframe->getCfg('absolute_path') . '/administrator/includes/pageNavigation.php');
  	$pageNav = new mosPageNav($total, $limitstart, $limit);
  	
  	$query = str_replace("%s", "*", $basequery);
  	$database->setQuery($query);
  	$rows = $database->loadObjectList();
  	echo $database->getErrorMsg();
  	
  	/** sort accoording to level **/
  	$level = 0;
    $tree = array(array());
    //sort by parent
    for($i=0,$n=count($rows);$i<$n;$i++){
      $row = $rows[$i];
      $tree[$row->parent_id][] = $row;
    }
    
    $final = array();
    $level = 0;
    //loop through all items
    for($i=0,$n=count($tree[$cid]);$i<$n;$i++){
      $row = $tree[$cid][$i];
      categories::recurseCategorie($tree, $final, $row, $level);
    }
  	
    $final = array_slice($final, $limitstart, $limit);
    
    $lists = array();
  	$lists['search'] = $search;
  	
  	$categories = categories::getCategorieTree();
  	
  	$obj = new stdClass();
  	$obj->id = 0;
  	$obj->name = ' - all - ';
  	
  	array_unshift($categories, $obj);
  	
  	$lists['cid'] = mosHTML::selectList($categories, 'cid', 'onchange="document.adminForm.submit();"', 'id', 'name', $cid);
  	
  	HTML_easycalendar::showCategories($final, $pageNav, $lists);
  }
  
  /**
   * Edit or add a category
   *
   * @param int $id
   */
  function edit($id){
    global $database, $my;
    
    $row = new mosCategory($database);
    $row->load($id);
    
    $categories = categories::getCategorieTree();
    
    $obj = new stdClass();
    $obj->id = 0;
    $obj->name = 'Top';
    
    array_unshift($categories, $obj);
    
    $lists = array();
  	$lists['parent_id'] = mosHTML::selectList( $categories, 'parent_id', 'class="inputbox" size="1"', 'id', 'name', $row->parent_id );
  	$lists['published'] = mosHTML::yesnoRadioList('published', '', intval($row->published));
  	$lists['access'] = mosAdminMenus::Access( $row );
    
    HTML_easycalendar::editCategory($row, $lists);
  }
  
  /**
   * Save changes to category
   *
   */
  function save($redirect = true){
    global $database, $task, $option, $my;
    
    $row = new mosCategory($database);
    $row->bind($_POST);
    
    if(!$row->id){
      $row->ordering = 999999999;
    }
    
    // avoid linking category to itself
    if($row->parent_id == $row->id){
      $row->parent_id = 0;
    }
    
    $row->section = 'com_easycalendar';
    
    $row->published = intval(mosGetParam($_REQUEST, 'published', 0));
    
    if (!$row->check()) {
			echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
			exit();
		}
		if (!$row->store()) {
			echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
			exit();
		}
		
		$row->updateOrder('section = \'com_easycalendar\'');
		
		if($redirect){
  		switch ($task){
  		  case 'save':
  		    mosRedirect('index2.php?option=' . $option . '&act=categories', 'Changes to category saved');
  		    break;
  		  case 'apply':
  		    mosRedirect('index2.php?option=' . $option . '&act=categories&task=edit&cid=' . $row->id . '&hidemainmenu=1', 'Changes to category saved');
  		    break;
  		}
		} else {
		  return $row->id;
		}
  }
  
  /**
   * Remove Categorie(s)
   *
   * @param array ids
   */
  function remove($cid){
    global $database, $option;
    
    $row = new mosCategory($database);
    
    for($i=0,$n=count($cid);$i<$n;$i++){
      $id = $cid[$i];
      
      $query = "SELECT COUNT(1) FROM #__easygallery WHERE cid = $id";
      $database->setQuery($query);
      $total = $database->loadResult();
      
      if($total > 0){
        echo "<script> alert('There are still events in the category you\'re trying to remove, remove them first'); window.history.go(-1); </script>\n";
  			exit();
      }
      
      $row->delete($id);
    }
    
    mosRedirect('index2.php?option=' . $option . '&act=categories', 'Selected categories removed');
  }
  
  /**
   * Set a Category state
   *
   * @param int id
   * @param int published
   */
  function setState($ids, $published){
    global $database, $option;
    
    $row = new mosCategory($database);
    for($i=0,$n=count($ids);$i<$n;$i++){
      $row->load($ids[$i]);
    
      $row->published = $published;
    
      if (!$row->store()) {
  			echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
  			exit();
  		}
    }
    
    mosRedirect('index2.php?option=' . $option . '&act=categories');
  }
  
  /**
   * Move an item up or down
   *
   * @param int $id
   * @param int $direction
   */
  function reorder($id, $direction){
    global $database, $option;
    
    $row = new mosCategory($database);
    $row->load($id);
    
    $row->move($direction, 'section = \'com_easycalendar\'');
    
    mosRedirect('index2.php?option=' . $option . '&act=categories');
  }
  
  /**
   * Change ordering of a lot of items
   *
   * @param array $cid
   */
  function saveOrder($cid){
    global $database, $option;
    
    $order = mosGetParam( $_POST, 'order', array(0) );
    $row = new mosCategory($database);
    $conditions = array();
    
    for($i=0,$n=count($cid);$i<$n;$i++){
			$row->load($cid[$i]);
			
			if ($row->ordering != $order[$i]) {
				$row->ordering = $order[$i];
				
				if (!$row->store()) {
				  echo "<script> alert('".$database->getErrorMsg()."'); window.history.go(-1); </script>\n";
  				exit();
				}
				
				$condition = "section = 'com_easycalendar'";
				$found = false;
				
				for($j=0,$k=count($conditions);$j<$k;$j++){
				  $cond = $conditions[$j];

				  if ($cond[1] == $condition) {
						$found = true;
						break;
					}
				}
			  if (!$found){
				  $conditions[] = array ($row->id, $condition);
				}
			}
		}

		for($i=0,$n=count($conditions);$i<$n;$i++){
		  $condition = $conditions[$i];
		  
			$row->load($condition[0]);
			$row->updateOrder($condition[1]);
		}
		
		mosRedirect('index2.php?option=' . $option . '&act=categories');
  }
  
  /**
   * Get the categorie tree
   *
   * @return array
   */
  function getCategorieTree($published_only = false){
    global $mainframe, $database;
    
    $query = "SELECT * FROM #__categories 
      WHERE section = 'com_easycalendar' ";
    if($published_only){
      $query .= "AND published = 1";
    }
    $query .= "ORDER BY parent_id, ordering";
    $database->setQuery($query);
    $rows = $database->loadObjectList();
    
    $level = 0;
    $tree = array(array());
    //sort by parent
    for($i=0,$n=count($rows);$i<$n;$i++){
      $row = $rows[$i];
      
      $tree[$row->parent_id][] = $row;
    }
    
    $final = array();
    $level = 0;
    //loop through all items
    for($i=0,$n=count($tree[0]);$i<$n;$i++){
      $row = $tree[0][$i];
      categories::recurseCategorie($tree, $final, $row, $level);
    }
    
    return $final;
  }
  
  /**
   * Recurse categories
   *
   * @param array all categories
   * @param array categorie tree
   * @param <var>dbDisplayCategorie</var> $row
   * @param int current level
   */
  function recurseCategorie($rows, &$tree, $row, $level){
    $name = '';
    
    for($i=0;$i<$level;$i++){
      $name .= '--';
    }
    if($level != 0){
      $name = '|' . $name;
    }
    $row->name = $name . ' ' . $row->name;
    
    $tree[] = $row;
    if(@sizeof($rows[$row->id])){
      for($i=0,$n=count($rows[$row->id]);$i<$n;$i++){
        
        $child = $rows[$row->id][$i];
        
        categories::recurseCategorie($rows, $tree, $child, $level + 1);  
      }
    }
  }
}