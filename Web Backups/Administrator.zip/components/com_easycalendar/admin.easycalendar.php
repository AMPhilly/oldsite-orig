<?php
/**
* @package Easy Calendar
* @copyright (C) 2006 Joomla-addons.org
* @author Websmurf
* 
* --------------------------------------------------------------------------------
* All rights reserved.  Easy Calender Component for Joomla!
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the Creative Commons - Attribution-NoDerivs 2.5 
* license as published by the Creative Commons Organisation
* http://creativecommons.org/licenses/by-nd/2.5/.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
* --------------------------------------------------------------------------------
**/

defined( '_VALID_MOS' ) or die( 'Restricted access' );

require_once($mainframe->getPath('class'));
require_once($mainframe->getPath('admin_html'));

$task = mosGetParam($_REQUEST, 'task');
$act = mosGetParam($_REQUEST, 'act');
$cid = mosGetParam($_REQUEST, 'cid', array(0));

if(!is_array($cid)){
  $cid = array($cid);
}

switch ($act){
  case 'categories':
    swCategories($task, $cid);
    break;
  case 'events':
    swEvents($task, $cid);
    break;
  case 'configuration':
    swConfiguration($task, $cid);
    break;
  default:
    HTML_easycalendar::showCredits();
    break;
}


/**
 * Switch for events
 *
 * @param string $task
 * @param array $cid
 */
function swEvents($task, $cid){
  global $option;
  
  switch ($task){
    case 'new':
      events::edit(0);
      break;
    case 'edit':
      events::edit($cid[0]);
      break;
    case 'apply':
    case 'save':
      events::save();
      break;
    case 'remove':
      events::remove($cid);
      break;
    case 'cancel':
      mosRedirect('index2.php?option=' . $option . '&act=events');
      break;
    case 'publish':
      events::setState($cid, 1);
      break;
    case 'unpublish':
      events::setState($cid, 0);
      break;
    default:
      events::show();
      break;
  }
}

/**
 * Switch for categories
 *
 * @param string $task
 * @param array $cid
 */
function swCategories($task, $cid){
  global $option;
  
  switch ($task){
    case 'new':
      categories::edit(0);
      break;
    case 'edit':
      categories::edit($cid[0]);
      break;
    case 'apply':
    case 'save':
      categories::save();
      break;
    case 'remove':
      categories::remove($cid);
      break;
    case 'cancel':
      mosRedirect('index2.php?option=' . $option . '&act=categories');
      break;
    case 'orderup':
      categories::reorder($cid[0], -1);
      break;
    case 'orderdown':
      categories::reorder($cid[0], 1);
      break;
    case 'saveorder':
      categories::saveOrder($cid);
      break;
    case 'publish':
      categories::setState($cid, 1);
      break;
    case 'unpublish':
      categories::setState($cid, 0);
      break;
    default:
      categories::show();
      break;
  }
}

function swConfiguration($task){
  global $option;
  
  switch ($task){
    case 'save':
    case 'apply':
      saveConfiguration();
      break;
    case 'cancel':
      mosRedirect('index2.php?option=' . $option);
      break;
    default:
      HTML_easycalendar::showConfiguration();
      break;
  }
}