<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class mosHotTopics extends mosDBTable {
	var $id				=null;
	var $Title			=null;
	var $SubTitle		=null;
	var $Author			=null;
	var $Date			=null;
	var $Article		=null;
	var $LinkName		=null;
	var $Url			=null;
	var $Photo1			=null;
	var $Caption1		=null;
	var $Photo2			=null;
	var $Caption2		=null;
	var $Photo3			=null;
	var $Caption3		=null;
	var $Gallery		=null;
	var $DocumentLink	=null;
	var $Document		=null;
	var $Archived		=null;
	var $Published		=null;
	var $ordering		=null;
	
	function mosHotTopics( &$db ) {
		$this->mosDBTable( '#__hot_topics', 'id', $db );
	}
	
	function schema() {
		 return "CREATE TABLE IF NOT EXISTS `J_hot_topics` (
		  `id` int(11) unsigned NOT NULL auto_increment,
		  `Title` varchar(255) NOT NULL,
		  `SubTitle` varchar(255) NOT NULL,
		  `Author` varchar(255) NOT NULL,
		  `Date` date NOT NULL,
		  `Article` text NOT NULL,
		  `LinkName` varchar(255) NOT NULL,
		  `Url` varchar(255) NOT NULL,
		  `Photo1` varchar(255) NOT NULL,
		  `Caption1` varchar(255) NOT NULL,
		  `Photo2` varchar(255) NOT NULL,
		  `Caption2` varchar(255) NOT NULL,
		  `Photo3` varchar(255) NOT NULL,
		  `Caption3` varchar(255) NOT NULL,
		  `Gallery` int(11) NOT NULL,
		  `DocumentLink` varchar(255) NOT NULL,
		  `Document` varchar(255) NOT NULL,
		  `Archived` enum('false','true') NOT NULL default 'false',
		  `Published` enum('false','true') NOT NULL default 'false',
		  `ordering` int(11) NOT NULL,
		  PRIMARY KEY  (`id`)
		) ENGINE=MyISAM;";
	}
}
?>
