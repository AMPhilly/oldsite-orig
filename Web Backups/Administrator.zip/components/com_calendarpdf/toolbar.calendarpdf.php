<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );

require_once( $mainframe->getPath( 'toolbar_html' ) );

switch ($task) {
	case 'new':
	case 'edit':
	case 'editA':
		TOOLBAR_news::_EDIT( );
		break;

	default:
		TOOLBAR_news::_DEFAULT();
		break;
}
?>