<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );
require_once("class.calendarpdf.php");

$cid = josGetArrayInts( 'cid' );
	
switch ($task) {
	case 'new':
		edit( 0 );
		break;

	case 'edit':
		edit( $id );
		break;

	case 'save':
	case 'apply':
		save( $task );
		break;

	case 'remove':
		remove( $cid, 'calendarpdf' );
		break;
	
	case 'cancel':
		view();
		break;

	default:
		view();
		break;
}

function view() {
	global $database, $mainframe, $mosConfig_list_limit,  $my, $acl, $mosConfig_offset;
	
	$limit = intval( mosGetParam( $_REQUEST, 'limit', $mosConfig_list_limit ) );
	$limitstart = intval( mosGetParam( $_REQUEST, 'limitstart', 0 ) );

	// get the total number of records
	$query = "SELECT count(*) FROM #__calendarpdf";
	
	$database->setQuery( $query );
	$total = $database->loadResult();
	
	require_once( $GLOBALS['mosConfig_absolute_path'] . '/administrator/includes/pageNavigation.php' );
	$pageNav = new mosPageNav( $total, $limitstart, $limit );

	$query = "SELECT * FROM #__calendarpdf ORDER BY Location ASC, Year DESC, Month DESC";
	$database->setQuery( $query, $pageNav->limitstart, $pageNav->limit );
	$rows = $database->loadObjectList();

	if ($database->getErrorNum()) {
		echo $database->stderr();
		return false;
	}

	mosCommonHTML::loadOverlib();
	?>
	<form enctype="multipart/form-data" action="index2.php?option=com_calendarpdf" method="post" name="adminForm">
	<table class="adminheading">
		<tr><th class="edit" rowspan="2" nowrap="nowrap">Manage Calendar PDF's</th></tr>
	</table>
	<table class="adminlist">
		<tr>
			<th width="5">#</th>
			<th width="5"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count( $rows ); ?>);" /></th>
			<th class="title">Month Year</th>
			<th class="title">Location</th>
		</tr>
	<?php
	$k = 0;
	$nullDate = $database->getNullDate();
	for ($i=0, $n=count( $rows ); $i < $n; $i++) {
		$row = &$rows[$i];

		mosMakeHtmlSafe($row);

		$link = 'index2.php?option=com_calendarpdf&task=edit&id='. $row->id;

		$access 	= mosCommonHTML::AccessProcessing( $row, $i );
		$checked 	= mosCommonHTML::CheckedOutProcessing( $row, $i );
		?>
		<tr class="<?= "row$k" ?>">
			<td><?= $pageNav->rowNumber( $i ) ?></td>
			<td align="center"><?php echo "<input type='checkbox' id='cb$i' name='cid[]' value='$row->id' onclick='isChecked(this.checked);' />"; ?></td>
			<td><a href="<?= $link ?>" title="Edit Content"><?= date("F", mktime(0, 0, 0, $row->Month, 1, 2000))." ".$row->Year ?></a></td>
			<td><?= $row->Location ?></td>
		</tr><?php
		$k = 1 - $k;
	}
	?>
	</table>
	<?php echo $pageNav->getListFooter(); ?>
	<input type="hidden" name="option" value="com_calendarpdf" />
	<input type="hidden" name="task" value="" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="hidemainmenu" value="0" />
	</form><?php
}

function edit( $uid=0 ) {
	global $database, $my, $mainframe, $mosConfig_absolute_path, $mosConfig_live_site, $mosConfig_offset;

	// load the row from the db table
	$row = new mosCalendarPDF( $database );
	$row->load( (int)$uid );
	
	$option = strval( mosGetParam( $_REQUEST, 'option', '' ) );

	$selected_folders = NULL;
	if ( $uid == 0 ) {
	}

	mosMakeHtmlSafe( $row );

	mosCommonHTML::loadOverlib();
	mosCommonHTML::loadCalendar();
	?>
	<script language="javascript" type="text/javascript">
	<!--
	function submitbutton(pressbutton) {
		var form = document.adminForm;

		if (pressbutton == 'cancel') {
			submitform( pressbutton );
			return;
		}
		submitform( pressbutton );
	}
	//-->
	</script>
	<form enctype="multipart/form-data" action="index2.php" method="post" name="adminForm">
		<table class="adminheading">
			<tr><th class="edit"><?php echo $row->id ? 'Edit' : 'Add';?> Calendar PDF</th></tr>
		</table>
		<table align="left" cellspacing="0" cellpadding="0" width="60%">
			<tr>
				<td width="60%" valign="top">
					<table width="100%" class="adminform">
						<tr>
							<td width="100%">
								<table cellspacing="0" cellpadding="0" border="0" width="100%">
									<tr><th colspan="4">PDF Details</th></tr>
									<?= displayUploadFile( $row, "PDF", "", "pdf" ) ?>
									<tr>
										<td>Month/Year:</td>
										<td>
											<select name="Month"><?php
												for($i = 1; $i < 13; $i++)
												{ ?>
													<option value="<?= $i ?>"<?php echo ($i == $row->Month ? " selected=\"selected\"" : "") ?>><?php echo date("F", mktime(0, 0, 0, $i, 1, 2000)); ?></option><?php
												} ?>
											</select>
											/
											<select name="Year"><?php
												$current_year = date("Y");
												for($i = $current_year; $i < $current_year + 2; $i++)
												{ ?>
													<option value="<?= $i ?>"<?php echo ($i == $row->Year ? " selected=\"selected\"" : "") ?>><?php echo $i; ?></option><?php
												} ?>
											</select>  
										</td>
									</tr>
									<tr>
										<td>Location:</td>
										<td>
											<select name="Location">
												<option value="Narberth"<?= $row->Location == "Narberth" ? " selected=\"selected\"" : "" ?>>Narberth</option>
												<option value="Paoli"<?= $row->Location == "Paoli" ? " selected=\"selected\"" : "" ?>>Paoli</option>
											</select>
										</td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<input type="hidden" name="id" value="<?= $row->id ?>" />
		<input type="hidden" name="option" value="com_calendarpdf" />
		<input type="hidden" name="task" value="save" />
	</form><?php
}
function save( $task ) {
	global $database, $my, $mainframe, $mosConfig_offset, $mosConfig_absolute_path;
	
	uploadFile2( "data/calendarpdf/pdf", "PDF", "pdf");
	
	$row = new mosCalendarPDF( $database );
	if (!$row->bind( $_POST )) {
		echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
		exit();
	}
	// sanitise id field
	$row->id = (int) $row->id;

 	if (!$row->check()) {
		echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
		exit();
	}
	
	// Test whether or not the Month Year combo is already in the db
	$sql = "SELECT id, Month, Year FROM #__calendarpdf WHERE id <> ".$row->id." AND Location='".$row->Location."' AND Month = ".$row->Month." AND Year = ".$row->Year;
	$database->setQuery($sql);
	$calendar_test = $database->loadObjectList();
	
	if(empty($calendar_test))
		$row->store();
	else
		$task = "error";

	// clean any existing cache files
	mosCache::cleanCache( 'com_calendarpdf' );
	switch ( $task ) {
		case 'apply':
			$msg = 'Successfully Saved changes to Item';
			mosRedirect( 'index2.php?option=com_calendarpdf&task=edit&id='. $row->id, $msg );
			break;
		
		case 'error':
			$msg = 'Failed to save changes to item: Month/Year combination already in Database';
			mosRedirect( 'index2.php?option=com_calendarpdf&task=edit&id='. $row->id, $msg );
			break;

		case 'save':
		default:
			mosRedirect( 'index2.php?option=com_calendarpdf' );
			break;
	}
}
function remove( &$cid, $table ) {
	global $database;
	
	$total = count( $cid );
	if ( $total < 1) {
		echo "<script> alert('Select an item to delete'); window.history.go(-1);</script>\n";
		exit;
	}

	//seperate contentids
	mosArrayToInts( $cid );
	$cids = 'id=' . implode( ' OR id=', $cid );
	$query = "DELETE FROM #__".$table." WHERE ( $cids )";
	$database->setQuery( $query );
	if ( !$database->query() ) {
		echo "<script> alert('".$database->getErrorMsg()."'); window.history.go(-1); </script>\n";
		exit();
	}

	// clean any existing cache files
	mosCache::cleanCache( 'com_'.$table );

	$msg 	= $total ." Item(s) sent to the Trash";
	mosRedirect( 'index2.php?option=com_'.$table, $msg );
}
?>