<?php
	$sql = "SELECT * FROM #__news WHERE id='".$id."'";
	$database->setQuery( $sql );
	$result = $database->loadObjectList();
	
	foreach( $result as $row ) { ?>
		<div class="content-item">
			<h1><?= $row->Title ?></h1>
			<?= etag( "h2", $row->SubTitle ) ?>
			<?= etag( "h2", $row->Date ) ?>
			<?= etag( "h3", $row->Author ) ?>
			<?= $row->Publication != "" ? "<h4>".$row->Publication.( $row->OriginalDate != "" ? " - ".$row->OriginalDate : "" )."</h4>" : "" ?>
			<?php
			if( $row->Photo1 != "" ) { ?>
			<div class="picture-box">
			<img src="../../data/news/images/<?= $row->Photo1 ?>" alt="<?= $row->Alt1 ?>" />
			<span><?= $row->Caption1 ?></span>
			
			</div><?
			} ?>
			
			<p><?= $row->Article ?></p>
			
			<p><?= displayLink( $row->Url, $row->LinkName ) ?></p>
			
			<p><?= displayDocument( "../../data/news/pdf/", $row->Document, $row->DocumentLink ) ?></p>
			
			<?php
			if( $row->Photo2 != "" ) { ?>
			<img src="../../data/news/images/<?= $row->Photo2 ?>" alt="<?= $row->Alt2 ?>" /><?
			} ?>
			
			<?php
			if( $row->Photo3 != "" ) { ?>
			<div class="picture-box">
			<img src="../../data/news/images/<?= $row->Photo3 ?>" alt="<?= $row->Alt3 ?>" />
			
			</div><?
			} ?>
			
			<?php
			if( $row->Photo4 != "" ) { ?>
			<img src="../../data/news/images/<?= $row->Photo4 ?>" alt="<?= $row->Alt4 ?>" style="float: left;" /><?
			} ?>
			
			<?php
			if( $row->Photo5 != "" ) { ?>
			<img src="../../data/news/images/<?= $row->Photo5 ?>" alt="<?= $row->Alt5 ?>" style="float: left;" /><?
			} ?>
			
			<?php
			if( $row->Photo6 != "" ) { ?>
			<img src="../../data/news/images/<?= $row->Photo6 ?>" alt="<?= $row->Alt6 ?>" style="float: left;" /><?
			} ?>
		</div><?php
	}
	
	function etag( $tag, $data, $default="" ) {
		return $data != "" ? "<".$tag.">".$data."</".$tag.">" : $default;
	}
	
	function displayLink( $href, $link ) {
		if( $href == "" or strlen($href) < 8 )
			return "";
		
		if( $link == "" )
			$link = $href;
			
		return "<a href=\"".$href."\">".$link."</a>";
	}
	
	function displayDocument( $path, $file, $link ) {
		if( $file == "" )
			return "";
		
		return displayLink( $path.$file, $link );
	}
 ?>
	