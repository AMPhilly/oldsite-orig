<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class mosCalendarPDF extends mosDBTable {
	var $id			=null;
	var $Location	=null;
	var $PDF		=null;
	var $Month		=null;
	var $Year		=null;
	var $Published	=null;
	
	function mosCalendarPDF( &$db ) {
		$this->mosDBTable( '#__calendarpdf', 'id', $db );
	}
	
	function schema() {
		 return "CREATE TABLE IF NOT EXISTS `J_calendarpdf` (
		  `id` int(11) unsigned NOT NULL auto_increment,
		  `Location` varchar(255) NOT NULL,
		  `PDF` varchar(255) NOT NULL,
		  `Month` int(11) NOT NULL,
		  `Year` int(11) NOT NULL,
		  `Published` enum('false','true') NOT NULL default 'false',
		  PRIMARY KEY  (`id`)
		) ENGINE=MyISAM;";
	}
}
?>
