<?php // compatibility

// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

require_once( dirname( __FILE__ ) . '/joomla.php' );
?>