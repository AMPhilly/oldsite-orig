<?php
	$im2 = ImageCreate(200, 50);

	$background_color = imagecolorallocate($im2, 0, 0, 0);
	$text_color = ImageColorAllocate($im2, 255, 0, 0);
	imagefttext( $im2, 20.0, 0, 0, 30, $text_color, "/web/captcha/GillSansMT.ttf", "Testing..." );
	
	//imagestring($im2, 1, 5, 5,  "A Simple Text String", $text_color);

	header("Content-Type: image/jpeg");
	ImageJPEG($im2);
?>