<?php
	require_once("../app.php");
	
	$_section = "getting-started";
	$_page = "programs-and-standards";
?>
<?php require_once($mosConfig_absolute_path."/templates/interior-header.php"); ?>

		<div id="main-cont">
			<div id="interior-top-sliver"></div>
			<div id="interior-bottom-sliver"></div>
			<div id="main">
				<?php require_once($mosConfig_absolute_path."/templates/nav/tertiary/getting-started.php"); ?>
				<div id="interior-wide-text-cont">
					<h1>Programs and Standards</h1>
					
					<h2>The Three Way System</h2>

					<p class="copy-header">Private Lessons</p>
					<h4>PURPOSE:<em> To develop technique and styling.</em></h4>
				  <p>Your <strong>private lessons</strong> are the backbone of your program as they encompass any individual problems you may have with your dancing. Your instructor can give you personal attention and work at your individual pace covering crucial, dancing points such as: timing, control, posture, balance, foot and body alignments, style and technique.</p>
                    <div class="light-dotted"></div>
					<img src="<?php echo $mosConfig_live_site ?>/images/prgms-stds.jpg" class="float-right"/>

				  <p class="copy-header">Class Instruction</p>
					<h4>PURPOSE:<em> To develop patterns, leading and following.</em></h4>
				  <p><strong>Group classes</strong> are the key to saving time in your quest to become a confident, fun partner. You will be learning new patterns while focusing on your leading and following skills. You will have the opportunity to dance with a variety of partners so you can practice leading and following the class material.<br /></p>
                    <div class="light-dotted"></div>
                    
				  <p class="copy-header">Practice Sessions (Dance Parties)</p>
					<h4>PURPOSE:<em> To develop continuity and confidence.</em></h4>
					<p><strong>Practice sessions</strong> are fun parties that allow you the time to PRACTICE!! They emulate nightclub settings so you can experience dancing on a crowded floor. Leading and following a variety of partners (beginners to advanced), will enable you to become a confident dancer quickly. Remember, to lead or follow your teacher is easy. Our goal is to train you to dance with any partner, good or poor, in any situation.</p>
					<p>&nbsp;</p>
				  <h2>Program Types &amp; Medalist Standards <br />
			      of the Arthur Murray Dance Schools</h2>

				  <p class="copy-header">Introductory Program:</p>
					<p>This program is designed as an introduction to the popular social dances. This allows you and your teacher an opportunity to assess and address your immediate dancing needs and evaluate your future dance goals.</p>
					<div class="light-dotted"></div>

				  <p class="copy-header">Basic:</p>
					<p>This program is designed to develop a few <strong>basic dances</strong>. Emphasis is placed on the three most important elements of dancing, namely, foot positions, rhythm and timing and leading or following.</p>
					<div class="light-dotted"></div>

					
				  <p class="copy-header">Associate Bronze:</p>
					<p>This is the program for the impatient dancer. It will develop free movement around the floor, much more variety, technique, footwork, and your first introduction to styling. This dance program is very popular with the person that wants to get on the floor right away. You will be checked out in each phase by an Arthur Murray Examiner.</p>
                    					<div class="light-dotted"></div>

					<img src="<?php echo $mosConfig_live_site ?>/images/prgms-stds-2.jpg" class="float-right"/>
				  <p class="copy-header">Full Bronze:</p>
					<p>Bronze is the full Social Standard. It is designed to develop timing and technique in all Social Dances. The styling will make you look nice and feel comfortable while on the floor. It will strengthen your lead and following to the point that no matter who your partner is, what kind of music or what type of dance floor, you will look poised and comfortable in all the popular social dances and many variations. It will give you all the confidence you will ever need on the dance floor. </p>
					<p>Dancing at this level will be yours to keep as you will never forget the elements of each dance. It is the fun point in dancing when you don't have to think about anything but enjoying your partner and having fun yourself. You will be checked out in each phase by an Arthur Murray Examiner. <strong>WOW! YOU ARE NOW A FULL-FLEDGED DANCER!!!</strong></p>
					<div class="light-dotted"></div>

					
				  <p class="copy-header">Silver:</p>
					<p>Silver is a dance standard with a high degree of styling. Flashy movements make this standard stand out on the dance floor. Continuity of movement makes a couple glide around the dance floor, with many changes in direction. Styling makes this standard develop an individual character -- some people become Smooth Dancers while others become Latin Dancers. Technique is very important to develop continuity movement. This standard is the beginning of the showy and flashy dancing to be used mainly on the ballroom floor. A Silver dancer is definitely noticed on a crowded floor.</p>
                    					<div class="light-dotted"></div>
                                        <p class="copy-header">Gold:</p>
					<p>Our Gold Standard is for the Stars! Strictly a standard for the hobby dancer or the person who wants to do exhibitions. The intricate patterns are only to be used when both people really know what they are doing. Choreography, Styling, Technique and Showmanship are necessities in this standard.  This is a beautiful standard to watch. If you choose this standard, be prepared to work hard. Your dedication to this program will earn you recognition as an outstanding dancer able to excel in any dance!</p>
					<p>&nbsp;</p>
				 
				</div>
				<div style="clear:both;"></div>
				<div id="video-link">
					<a href="<?= $mosConfig_live_site ?>/photos-and-testimonials/why-dance-infomercial.php?part=Dances"><img src="<?php echo $mosConfig_live_site ?>/images/dances-video-icon.jpg" /></a>
				</div>
			</div>
		</div>

<?php require_once($mosConfig_absolute_path."/templates/footer.php"); ?>