<?php
	require_once("../app.php");
	
	$_section = "getting-started";
	$_page = "weddings";
?>
<?php require_once($mosConfig_absolute_path."/templates/interior-header.php"); ?>

		<div id="main-cont">
			<div id="interior-top-sliver"></div>
			<div id="interior-bottom-sliver"></div>
			<div id="main">
				<?php require_once($mosConfig_absolute_path."/templates/nav/tertiary/getting-started.php"); ?>
				<div id="interior-wide-text-cont">

					<h1>Dancing at Your Wedding</h1>
					<h2>Wedding Dance Tips:</h2>
					<img src="<?php echo $mosConfig_live_site ?>/images/wedding.jpg" class="float-right"/>

                    <p>
						<strong>Learning to dance for your wedding</strong> is a great way to spend time together before the big day 
						and to develop a skill that will last forever.  We will help you create a special moment 
						where the two of you can enjoy the closeness of one another, dancing to a special song 
						without feeling awkward or afraid.  The investment of time and money will be the best one 
						you make for your wedding day.  A year from now or twenty years from now you and your 
						spouse will still be dancing!					</p>
					
<ul>
						<li>
							We know that Brides and Grooms today have very busy and demanding schedules that create stress.  
							  <strong>Dancing is considered a low impact aerobic activity </strong>so taking dance lessons not only gives 
							you a chance to exercise, it can also help you unwind after a busy day.						</li>
<li><strong> Start early! </strong>The closer you get to your wedding day the more demands there will be for 
							your time.  We recommend starting six months to a year in advance.  This will give you and 
							your fianc&eacute; plenty of time to practice and develop a natural and confident look.						</li>
						<li>
							Be patient and encourage one another through the learning process, especially if you are new 
							to dancing.  Much like learning a new sport, part of <strong>learning to dance is developing new 
							muscle memory</strong> and the key to this is repetition.						</li>
<li>
							Immerse yourselves in dance the first couple of weeks and the payoff will be big! Coming 
							to the studio as much as possible in the beginning can really help move you and your fianc&eacute; 
							through the initial learning stages so that dancing together will be fun and exciting.
						</li>
						<li>
							Think about the other dance opportunities at your wedding.  <br />
						  Some of the <strong>other traditional 
							dances</strong> that are done:<br />
          <br />

							Mother - Son<br />
							Father - Daughter<br />
							<br />
							Choosing the music and learning the appropriate dance will help make these moments a great experience as well.
						</li>
				  </ul>
					
					<p>
						Call us today to schedule an appointment with one of our wedding specialists.  Make your first dance
						a beautiful memory.  (610) 668-8870.  <a href="<?php echo $mosConfig_live_site ?>/getting-started/new-student-offer.php">SPECIAL INTRODUCTORY OFFER</a>
					</p>
				</div>
				<div style="clear:both;"></div>
				<div id="video-link">
					<a href="<?= $mosConfig_live_site ?>/photos-and-testimonials/why-dance-infomercial.php?part=Dances"><img src="<?php echo $mosConfig_live_site ?>/images/dances-video-icon.jpg" /></a>
				</div>
			</div>
		</div>

<?php require_once($mosConfig_absolute_path."/templates/footer.php"); ?>