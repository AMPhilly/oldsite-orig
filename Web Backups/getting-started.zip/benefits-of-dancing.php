<?php
	require_once("../app.php");
	
	$_section = "getting-started";
	$_page = "benefits-of-dancing";
?>
<?php require_once($mosConfig_absolute_path."/templates/interior-header.php"); ?>

		<div id="main-cont">
			<div id="interior-top-sliver"></div>
			<div id="interior-bottom-sliver"></div>
			<div id="main">
				<?php require_once($mosConfig_absolute_path."/templates/nav/tertiary/getting-started.php"); ?>
				<div id="interior-wide-text-cont">
					<h1>Benefits of Dancing</h1>
					
					<h2>Dancing: The Ideal Exercise</h2>
					<p>
						Exercising by jogging (outdoors/treadmill) is an unattractive alternative for many people. 
						Dancing is a mild form of an aerobic workout and <strong>dance lessons make exercise a fun</strong> and enjoyable 
						social event any night of the week. Your <strong>dance "workout"</strong> is beneficial in many ways:					</p>
					
<ul>
						<li>Olympic athletes often include <strong>dance</strong> in their training <br />
					    to sharpen control, agility, speed and balance</li>
	    <li><strong>Dance</strong> contributes to good posture and body alignment</li>
		<li><strong>Dance</strong> encourages gentle stretching</li>
		<li><strong>Dance</strong> increases your flexibility and stamina</li>
		<li><strong>Dance </strong>benefits your cardiovascular system as you swing and sway from hip to shoulders</li>
				  </ul>
					
					<h2>Dancing: A Romantic Alternative</h2>
					<img src="<?php echo $mosConfig_live_site ?>/images/benefits.jpg" class="float-right"/>
<p class="copy-header">
						The romantic properties of dance are a secret that all good dancers enjoy:
					</p>
					
					<p>
						Men feel confident when they recognize which dance is being played and 
					  have the ability to 
						walk across the dance floor and ask a lady to dance.					</p>
					
			  <p>
						Women will enjoy being asked to dance knowing they have mastered 
					  the grace, poise, styling 
						and important following skills of a trained dancer.					</p>
					
	  <p>
						Couples can add the romantic skills that come with the holding, touching and moving to the 
						music that dancing provides.
					</p>
					
					<p>
						Single people can meet new friends as dancing provides a natural icebreaker and 
					  becomes a common denominator in any crowd.					</p>
					
	  <p>
						A tailored program at the <strong>Arthur Murray Dance Studio</strong> is all you need to turn your dancing and romantic life around.					</p>
					
<p>
						Learning to dance is as easy as one, two, FREE when you take advantage of our <a href="<?php echo $mosConfig_live_site ?>/getting-started/new-student-offer.php">SPECIAL INTRODUCTORY OFFER!</a>
					</p>
					
					<p>
						It's easier than you think. You will feel completely at home in the friendly atmosphere of the Narberth and Paoli <strong>Arthur Murray 
						Dance Studios</strong>. Learn the newest steps and brush up on the most popular ballroom dances.					</p>
					
<p>
						Come on now! It's a proven way to have fun, meet new friends and stay in shape! <br />
					  Call the studio and get started today.
						Couples and singles invited.					</p>
			  </div>
				<div style="clear:both;"></div>
				<div id="video-link">
					<a href="<?= $mosConfig_live_site ?>/photos-and-testimonials/why-dance-infomercial.php?part=Benefits"><img src="<?php echo $mosConfig_live_site ?>/images/benefits-video-icon.jpg" /></a>
				</div>
			</div>
		</div>

<?php require_once($mosConfig_absolute_path."/templates/footer.php"); ?>