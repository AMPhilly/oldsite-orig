Event.observe(window, 'load', function() {
	
	if($('secondary-nav') != null) {
		var tables = $('secondary-nav').select('table');
		tables.each(function(s) {
			if($(s).hasClassName('active') == false) {
				$(s).observe('mouseover', sec_nav_swap);
				$(s).observe('mouseout', sec_nav_swap);
			}
		});
	}
	
	if($('tert-nav') != null) {
		var tables = $('tert-nav').select('table');
		tables.each(function(s) {
			if($(s).up('li').hasClassName('active') == false) {
				$(s).observe('mouseover', tert_nav_swap);
				$(s).observe('mouseout', tert_nav_swap);
			}
		});
	}
	
	if($('map') != null) {
		loadMap();
	}
});

function sec_nav_swap(event) {
	var el = Event.findElement(event, 'table');
	
	if(el.hasClassName('hover') == true)
		el.removeClassName('hover');
	else
		el.addClassName('hover');
}

function tert_nav_swap(event) {
	var el = Event.findElement(event, 'li');
	
	if(el.hasClassName('hover') == true)
		el.removeClassName('hover');
	else
		el.addClassName('hover');
}

var geocoder;
var map;
var dirObj;

function requestdirections2(mapobj,toaddr,fromaddr)
{
	if( typeof(dirObj) != 'undefined')
	{
		dirObj.clear();
	}
	mapobj.clearOverlays();
	$('directions').innerHTML = "";
	dirObj = new GDirections(mapobj,document.getElementById("directions"));
	dirObj.load('from:'+fromaddr+' to: '+toaddr);
	return false;
}

function showAddress(address) {
	map = new GMap2(document.getElementById("map"));
	geocoder = new GClientGeocoder();
	
	geocoder.getLatLng(
		address,
		function(point) {
			if (!point) {
				alert(address + " not found");
			} else {
				map.addControl(new GSmallMapControl());
				map.setCenter(point, 14);
				var marker = new GMarker(point);
				map.addOverlay(marker);
				marker.openInfoWindowHtml(building_name+"<br />"+building_street+"<br />"+building_city+" "+building_state+" "+building_zip+"<br />"+building_phone);
			}
		}
	);
}

function loadMap()
{
	if(GBrowserIsCompatible())
	{
		$('directions').innerHTML = "";
		showAddress(building_address);
	}
}

function arrow_down_right(id)
{
	var is_vis = Element.visible(id);
	if (false) {
		if (is_vis) { $(id).hide(); } else { $(id).show(); }
		$(id + "_img").src = (is_vis) ? "images/small-right.gif" : "images/small-down.gif";
	} else {
		var args = arguments[1] || {duration: 0.25};
		if (is_vis) {
			args.afterFinish = function () { $(id + "_img").src = "images/small-right.gif"; }
		} else {
			args.afterFinish = function () { $(id + "_img").src = "images/small-down.gif"; }
		}
		new Effect[is_vis ? 'BlindUp' : 'BlindDown'](id, args);
	}
}

function validateForm(f)
{
	var errMsg = "";
	if (f.FullName.value.length == 0)
		errMsg += "Name is required.\n";
	
	errMsg += checkPhone(f.Phone.value);
	
	if (f.word.value.length == 0)
		errMsg += "Security Code is required.\n";

	if (errMsg != "")
	{
		alert("Please fix the following errors: \n" + errMsg);
		return false;
	}
	
	f.submit();
}

function validateNewsletterForm(f)
{
	var errMsg = "";
	if (f.FullName.value.length == 0)
		errMsg += "Name is required.\n";
	
	if (f.Email.value.length == 0)
		errMsg += "Email is required.\n";
	
	if (f.word.value.length == 0)
		errMsg += "Security Code is required.\n";

	if (errMsg != "")
	{
		alert("Please fix the following errors: \n" + errMsg);
		return false;
	}
	
	f.submit();
}

function checkPhone(strng)
{
	var error = "";
	
	if (strng == "")
	   error = "You didn't enter a phone number.\n";
	
	var stripped = strng.replace(/[\(\)\.\-\ ]/g, ''); //strip out acceptable non-numeric characters
	
	if (isNaN(parseInt(stripped)))
	   error = "The phone number contains illegal characters.\n";
	else if (stripped.length == 0)
		error = "Phone number is required.\n";
	else if (!(stripped.length == 10))
		error = "The phone number is the wrong length. Make sure you included an area code.\n";
	
	return error;
}