// UK lang variables

tinyMCE.addToLang('layer',{
insertlayer_desc : 'Insert new layer',
forward_desc : 'Move forward',
backward_desc : 'Move backward',
absolute_desc : 'Toggle absolute positioning',
content : 'New layer...'
});
