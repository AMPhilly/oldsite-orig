<?php
	require_once("../app.php");
	
	$_page = "photo-galleries";
	$_section = "photos-and-testimonials";
?>
<?php require_once($mosConfig_absolute_path."/templates/interior-header.php"); ?>

		<div id="main-cont">
			<div id="interior-top-sliver"></div>
			<div id="interior-bottom-sliver"></div>
			<div id="main">
				<?php require_once($mosConfig_absolute_path."/templates/nav/tertiary/photos-and-testimonials.php"); ?>
				<div id="interior-wide-text-cont">
					<h1>Class/Event Photo Galleries</h1>
					
					<p>To view our ShutterFly Studio Gallery <a href="http://arthurmurraynarberth.shutterfly.com/" target="_blank">click here</a></p><?php
						
						if( isset($_GET['id']) and $_GET['id'] > 0 )
						{
							$sql = "SELECT * FROM #__photo WHERE Published = 'true' AND GID = ".$_GET['id']." ORDER BY ordering ASC";
							$database->setQuery($sql);
							$rows = $database->loadObjectList();
							
							if( count($rows) > 0 )
							{ 
								$sql = "SELECT Name FROM #__gallery WHERE id = ".$_GET['id'];
								$database->setQuery($sql);
								$GalleryName = $database->loadResult(); ?>
								<p class="copy-header"><?= $GalleryName ?></p>
								<p><a href="<?= $mosconfig_live_site ?>/photos-and-testimonials/photo-galleries.php">back to list of galleries</a></a>
								<div class="dhonishow effect_blind duration_2 autoplay_5"><?php
								foreach( $rows as $row )
								{ ?>
									<img src="<?= $mosConfig_live_site ?><?= resizeImage( "/data/gallery/images/".$row->Photo, 550, 400) ?>" alt="<?= $row->Caption ?>" /><?php
								} ?></div><?php
							}
						}
						else
						{
							$sql = "SELECT * FROM #__gallery WHERE Published = 'true'";
							$database->setQuery( $sql );
							$rows = $database->loadObjectList();
							
							if( count($rows) > 0 )
							{
								foreach( $rows as $row )
								{ ?>
									<div class="content-item">
										<h2><a href="<?= $mosConfig_live_site ?>/photos-and-testimonials/photo-galleries/<?= $row->id ?>/"><?= $row->Name ?></a></h2>
										<p><?= $row->Description ?></p>
									</div><?php
								}
							}
						} ?>
				</div>
				<div style="clear:both;"></div>
				<div id="video-link">
					<a href="<?= $mosConfig_live_site ?>/photos-and-testimonials/why-dance-infomercial.php?part=Dances"><img src="<?php echo $mosConfig_live_site ?>/images/dances-video-icon.jpg" /></a>
				</div>
			</div>
		</div>

<?php require_once($mosConfig_absolute_path."/templates/footer.php"); ?>