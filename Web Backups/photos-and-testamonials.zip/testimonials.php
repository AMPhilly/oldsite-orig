<?php
	require_once("../app.php");
	
	$_page = "testimonials";
	$_section = "photos-and-testimonials";
?>
<?php require_once($mosConfig_absolute_path."/templates/interior-header.php"); ?>

		<div id="main-cont">
			<div id="interior-top-sliver"></div>
			<div id="interior-bottom-sliver"></div>
			<div id="main">
				<?php require_once($mosConfig_absolute_path."/templates/nav/tertiary/photos-and-testimonials.php"); ?>
				<div id="interior-wide-text-cont">
					<h1>Client Testimonials</h1><?php
	
					$sql = "SELECT * FROM #__testimonial WHERE Published = 'true' ORDER BY Title ASC";
					$database->setQuery( $sql );
					$rows = $database->loadObjectList();
					
					$i = 0;
					
					foreach( $rows as $row )
					{ ?>
						<div class="content-item">
							<table cellpadding="0" cellspacing="0">
								<tr>
									<td valign="top" width="110">
										<div class="picture-box"><?php
										if( $row->Photo != "" ) { ?>
											<img src="<?= $mosConfig_live_site ?><?= resizeImage( "/data/testimonial/images/".$row->Photo, 100, 100) ?>" /><?php
										} ?></div>
									</td>
									<td valign="top">
										<h2><a href="<?= $mosConfig_live_site ?>/photos-and-testimonials/testimonial/<?= $row->id ?>/"><?= $row->Author ?></a></h2>
										<p class="copy-header"><?= $row->Location ?></p>
										<p><?= nl2br( ellipsis_no_cut_word( stripHTML( $row->Copy ), 200 ) ) ?> <a href="<?= $mosConfig_live_site ?>/photos-and-testimonials/testimonial/<?= $row->id ?>/">READ MORE</a></p>
									</td>
								</tr>
							</table>
							<div style="clear: both;"></div>
						</div><?php
					} ?>
				</div>
				<div style="clear:both;"></div>
				<div id="video-link">
					<a href="<?= $mosConfig_live_site ?>/photos-and-testimonials/why-dance-infomercial.php?part=Dances"><img src="<?php echo $mosConfig_live_site ?>/images/dances-video-icon.jpg" /></a>
				</div>
			</div>
		</div>

<?php require_once($mosConfig_absolute_path."/templates/footer.php"); ?>