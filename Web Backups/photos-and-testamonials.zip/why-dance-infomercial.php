<?php
	require_once("../app.php");
	
	$_page = "why-dance-infomercial";
	$_section = "photos-and-testimonials";
?>
<?php require_once($mosConfig_absolute_path."/templates/interior-header.php"); ?>

		<div id="main-cont">
			<div id="interior-top-sliver"></div>
			<div id="interior-bottom-sliver"></div>
			<div id="main">
				<?php require_once($mosConfig_absolute_path."/templates/nav/tertiary/photos-and-testimonials.php"); ?>
				<div id="interior-wide-text-cont">
					<h1>"Why Dance?" Infomercial</h1>
					
					<p>
						<a<?= $_GET['part'] == 'Benefits' ? " class=\"active\"" : "" ?> href="<?= $mosConfig_live_site ?>/photos-and-testimonials/why-dance-infomercial.php?part=Benefits">Benefits of Dancing</a> > 
						<a<?= $_GET['part'] == 'History' ? " class=\"active\"" : "" ?> href="<?= $mosConfig_live_site ?>/photos-and-testimonials/why-dance-infomercial.php?part=History">History of Arthur Murray</a> > 
						<a<?= $_GET['part'] == 'GetStarted' ? " class=\"active\"" : "" ?> href="<?= $mosConfig_live_site ?>/photos-and-testimonials/why-dance-infomercial.php?part=GetStarted">Getting Started</a> > 
						<a<?= $_GET['part'] == 'Dances' ? " class=\"active\"" : "" ?> href="<?= $mosConfig_live_site ?>/photos-and-testimonials/why-dance-infomercial.php?part=Dances">Dances</a> > 
						<a<?= $_GET['part'] == 'Method' ? " class=\"active\"" : "" ?> href="<?= $mosConfig_live_site ?>/photos-and-testimonials/why-dance-infomercial.php?part=Method">Teaching Method</a>
					</p>
					
					<?php
						if(isset($_GET['part']))
						{
							$docId = $_GET['part'].".flv";
						}
						else
						{
							$docId = "Dances.flv";
						}
					?>
					
					<div id="video-cont" style="text-align: center; padding-top: 20px;"></div>

					<script type='text/javascript'>
						var s1 = new SWFObject('/data/flash/player.swf','ply','480','360','9','#ffffff');
						s1.addParam('allowfullscreen','false');
						s1.addParam('allowscriptaccess','always');
						s1.addParam('wmode','opaque');
						s1.addParam('flashvars','file=<?= $mosConfig_live_site ?>/data/videos/<?= $docId ?>&autostart=true');
						s1.write('video-cont');
					</script>
				</div>
				<div style="clear:both;"></div>
				<div id="video-link">
					<a href="<?= $mosConfig_live_site ?>/photos-and-testimonials/why-dance-infomercial.php?part=Dances"><img src="<?php echo $mosConfig_live_site ?>/images/dances-video-icon.jpg" /></a>
				</div>
			</div>
		</div>

<?php require_once($mosConfig_absolute_path."/templates/footer.php"); ?>