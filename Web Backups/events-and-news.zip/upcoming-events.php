<?php
	require_once("../app.php");
	
	$_section = "events-and-news";
	$_page = "upcoming-events";
?>
<?php require_once($mosConfig_absolute_path."/templates/interior-header.php"); ?>


		<div id="main-cont">
			<div id="interior-top-sliver"></div>
			<div id="interior-bottom-sliver"></div>
			<div id="main">
				<?php require_once($mosConfig_absolute_path."/templates/nav/tertiary/events-and-news.php"); ?>
				<div id="interior-wide-text-cont">
					<h1>Upcoming Events</h1><?php
	
					if( isset( $_GET['id'] ) and $_GET['id'] != "" )
						$sql = "SELECT * FROM #__event WHERE Published = 'true' AND id = ".$_GET['id']."  ORDER BY ordering ASC";
					else
						$sql = "SELECT * FROM #__event WHERE Published = 'true' AND Archived = 'false' ORDER BY ordering ASC";
						
					$database->setQuery( $sql );
					$result = $database->loadObjectList();
						
					if( count($result) == 1 )
					{
						foreach( $result as $row )
						{ ?>
							<div class="content-item">
								<?php
									if( $row->StartDate != "0000-00-00" ) {
										$value = "<h2 class=\"date\">".date( "F j, Y", strtotime($row->StartDate));
										if( $row->EndDate != "0000-00-00" )
											$value .= " - ".date( "F j, Y", strtotime($row->EndDate))."</h2>";
										else
											$value .= "</h2>";
									}
									else if( $row->EndDate != "0000-00-00" )
										$value = "<h2 class=\"date\">".date( "F j, Y", strtotime($row->EndDate))."</h2>";
									else
										$value = "";
									
									echo $value; ?>
								<h1><?= $row->Title ?></h1>
								<?= etag( "h2", $row->Subtitle ) ?>
								<?php
									if( $row->Photo1 != "" )
									{ ?>
										<div class="picture-box"><img style="margin-left: 8px; padding-right: 8px; padding-bottom: 8px; float: left;" src="<?= $mosConfig_live_site ?><?= resizeImage( "/data/news/images/".$row->Photo1, 280, 400) ?>" alt="<?= $row->Caption1 ?>" /></div><?php
									}
								?>
								
								<p><?= $row->Description ?></p>
								
								<?php
									if( $row->Photo2 != "" )
									{ ?>
										<div class="picture-box"><img style="margin-left: 8px; padding-right: 8px; padding-bottom: 8px; float: left;" src="<?= $mosConfig_live_site ?><?= resizeImage( "/data/news/images/".$row->Photo2, 280, 400) ?>" alt="<?= $row->Caption2 ?>" /></div><?php
									}
								?>
								<?php
									if( $row->Photo3 != "" )
									{ ?>
										<div class="picture-box"><img style="margin-left: 8px; padding-right: 8px; padding-bottom: 8px; float: left;" src="<?= $mosConfig_live_site ?><?= resizeImage( "/data/news/images/".$row->Photo3, 280, 400) ?>" alt="<?= $row->Caption3 ?>" /></div><?php
									}
								
									if( $row->Gallery > 0 )
									{ ?>
										<p><a href="<?= $mosConfig_live_site ?>/photos-and-testimonials/photo-galleries/<?= $row->Gallery ?>/">View More Photos</a></p><?php
									}
								?>
					
								<p><?= displayLink( $row->Url, $row->LinkName ) ?></p>
								
								<p><?= displayDocument( $mosConfig_live_site."/data/event/pdf/", $row->Document, $row->DocumentLink ) ?></p>
							</div>
							<div style="clear: both;"></div><?php
						}
					}
					else
					{
						if( count($result) == 0 )
							echo "<p>No Events at this time.</p>";
						else
						{
							foreach( $result as $row )
							{ ?>
								<div class="content-item">
									<?php
										if( $row->StartDate != "0000-00-00" ) {
											$value = "<h2 class=\"date\">".date( "F j, Y", strtotime($row->StartDate));
											if( $row->EndDate != "0000-00-00" )
												$value .= " - ".date( "F j, Y", strtotime($row->EndDate))."</h2>";
											else
												$value .= "</h2>";
										}
										else if( $row->EndDate != "0000-00-00" )
											$value = "<h2 class=\"date\">".date( "F j, Y", strtotime($row->EndDate))."</h2>";
										else
											$value = "";
										
										echo $value; ?>
									<table cellpadding="0" cellspacing="0">
										<tr>
											<td align="center" valign="top" width="90">
												<div class="picture-box"><?php
												if( $row->Photo1 != "" ) { ?>
													<img src="<?= $mosConfig_live_site ?><?= resizeImage( "/data/event/images/".$row->Photo1, 75, 75) ?>" /><?php
												} ?></div>
											</td>
											<td>
												<h1 class="list-view"><?= $row->Title ?></h1>
												<?= etag( "h2", $row->SubTitle ) ?>
												<p><?= ellipsis_no_cut_word( stripHTML( $row->Description ), 180 ) ?></p>
											</td>
										</tr>
									</table>
								</div>
								<div style="clear: both;"></div><?php
							}
						}
					}
				?>
				</div>
				<div style="clear:both;"></div>
				<div id="video-link">
					<a href="<?= $mosConfig_live_site ?>/photos-and-testimonials/why-dance-infomercial.php?part=Dances"><img src="<?php echo $mosConfig_live_site ?>/images/dances-video-icon.jpg" /></a>
				</div>
			</div>
		</div>

<?php require_once($mosConfig_absolute_path."/templates/footer.php"); ?>