<?php
	require_once("../app.php");
	
	$_section = "events-and-news";
	$_page = "events";
?>
<?php require_once($mosConfig_absolute_path."/templates/interior-header.php"); ?>

		<div id="main-cont">
			<div id="interior-top-sliver"></div>
			<div id="interior-bottom-sliver"></div>
			<div id="main">
				<?php require_once($mosConfig_absolute_path."/templates/nav/tertiary/events-and-news.php"); ?>
				<div id="interior-calendar-cont">
					<h1>Events</h1>
					<div id="calendar-cont">
						<table cellpadding="0" cellspacing="0" width="90%" border="0">
							<tr>
								<td width="50%" valign="top">
									<h2>Narberth Studio Calendar</h2>
									<?php
										$query = "SELECT * FROM #__calendarpdf WHERE Location='Narberth' ORDER BY Year DESC, Month DESC";
										$database->setQuery($query);
										$cals = $database->loadObjectList();
										
										if (!empty($cals)) {
											echo "<ul>";
											foreach ($cals as $cal) { ?>
												<li><a href="<?= $mosConfig_live_site ?>/data/calendarpdf/pdf/<?= $cal->PDF ?>"><?= date("F", mktime(0, 0, 0, $cal->Month, 1, 2000))." ".$cal->Year ?></a></li>
												<?php
											}
											echo "</ul>";
										} else {
											echo "<p class=\"date\">No Calendars at this time.</p>";
										}
									?>
								</td>
								<td width="50%" valign="top">
									<h2>Paoli Studio Calendar</h2>
									<?php
										$query = "SELECT * FROM #__calendarpdf WHERE Location='Paoli' ORDER BY Year DESC, Month DESC";
										$database->setQuery($query);
										$cals = $database->loadObjectList();
										
										if (!empty($cals)) {
											echo "<ul>";
											foreach ($cals as $cal) { ?>
												<li><a href="<?= $mosConfig_live_site ?>/data/calendarpdf/pdf/<?= $cal->PDF ?>"><?= date("F", mktime(0, 0, 0, $cal->Month, 1, 2000))." ".$cal->Year ?></a></li>
												<?php
											}
											echo "</ul>";
										} else {
											echo "<p class=\"date\">No Calendars at this time.</p>";
										}
									?>
								</td>
							</tr>
						</table>
					</div>
			  </div>
				<div style="clear:both;"></div>
				<div id="video-link">
					<a href="<?= $mosConfig_live_site ?>/photos-and-testimonials/why-dance-infomercial.php?part=Dances"><img src="<?php echo $mosConfig_live_site ?>/images/dances-video-icon.jpg" /></a>
				</div>
			</div>
		</div>

<?php require_once($mosConfig_absolute_path."/templates/footer.php"); ?>/templates/footer.php"); ?>