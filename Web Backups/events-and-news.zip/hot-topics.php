<?php
	require_once("../app.php");
	
	$_section = "events-and-news";
	$_page = "hot-topics";
?>
<?php require_once($mosConfig_absolute_path."/templates/interior-header.php"); ?>

		<div id="main-cont">
			<div id="interior-top-sliver"></div>
			<div id="interior-bottom-sliver"></div>
			<div id="main">
				<?php require_once($mosConfig_absolute_path."/templates/nav/tertiary/events-and-news.php"); ?>
				<div id="interior-wide-text-cont">
					<h1>Hot Topics</h1><?php
	
					if( isset( $_GET['id'] ) and $_GET['id'] != "" )
					{
						$where = " WHERE id = ".$_GET['id'];
					}
				
					$sql = "SELECT * FROM #__hot_topics".$where." ORDER BY Date DESC";
					$database->setQuery( $sql );
					$result = $database->loadObjectList();
					
					$row_count = count( $result );
					
					if( $row_count == 1 )
					{
						displayFullHotTopic( $result[0] );
					}
					else if( $where != "" and $row_count == 0 )
					{
						$sql = "SELECT * FROM #__hot_topics ORDER BY Date DESC";
						$database->setQuery( $sql );
						$result = $database->loadObjectList();
						
						$row_count = count( $result );
						
						if( $row_count == 0 )
							echo "<p>No Hot Topics</p>";
						else
						{	
							foreach( $result as $row )
							{
								displayHotTopics( $row );
							}
						}
					}
					else if( $row_count == 0 )
						echo "<p>No Hot Topics</p>";
					else
					{
						foreach( $result as $row )
						{
							displayHotTopics( $row );
						}
					} ?>
				</div>
				<div style="clear:both;"></div>
				<div id="video-link">
					<a href="<?= $mosConfig_live_site ?>/photos-and-testimonials/why-dance-infomercial.php?part=Dances"><img src="<?php echo $mosConfig_live_site ?>/images/dances-video-icon.jpg" /></a>
				</div>
			</div>
		</div>

<?php require_once($mosConfig_absolute_path."/templates/footer.php"); ?>