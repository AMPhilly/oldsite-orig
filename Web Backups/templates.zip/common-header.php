<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="description" content="<?= !empty($_page_meta_description) ? $_page_meta_description : "Arthur Murray Dance Studio serves the Philadelphia, Ardmore, Narberth, Bala Cynwyd, Bryn Mawr, 
        Narberth, Paoli and Lower Merion areas by providing dance instruction, classes, and lessons for salsa, weddings, and dancing in clubs. 
        Dance lessons are available. for swing, hustle, samba, merengue, fox trot, rumba, salsa, cha-cha, mambo, waltz, tango, country." ?>" />

		<meta name="keywords" content="<?= !empty($_page_meta_keywords) ? $_page_meta_keywords : "dance, dance studio, dance lessons, tango, ballroom dance classes, ballroom dancing Philadelphia, salsa dance lessons, dance schools, dance school, dancing, dance instruction, dance class, learn to dance, Philadelphia dance studio, Narberth dance studio, Paoli dance studio,  Ardmore dance studio, Main Line dance studio, dance lessons Philadelphia, dance lessons Main Line, dance lessons Ardmore,  dance lessons Paoli, dance lessons Narberth, Arthur Murray Dance" ?>" />

<meta name="robots" content="Index,ALL" />
<meta name="revisit-after" content="7 Days" />
<meta name="rating" content="General" />
<meta name="language" content="en" />
<meta name="distribution" content="Global" />

		<title><?= !empty($_page_title) ? $_page_title : "Arthur Murray Dance Studio serves Philadelphia, Ardmore, Narberth, Bala Cynwyd, Bryn Mawr, Narberth and Lower Merion areas offering Ballroom dancing, Salsa dance classes, dance lessons, and dancing classes." ?></title>
        
        
		<link media="all" type="text/css" rel="stylesheet" href="<?php echo $mosConfig_live_site ?>/css/main.css" />
		<link media="all" type="text/css" rel="stylesheet" href="<?php echo $mosConfig_live_site ?>/css/<?= $mosConfig_theme ?>/main.css" />
		<link media="all" type="text/css" rel="stylesheet" href="<?php echo $mosConfig_live_site ?>/css/dhonishow.css" />
		<script type="text/javascript" language="javascript" src="<?php echo $mosConfig_live_site ?>/js/prototype.js"></script>
		<script type="text/javascript" language="javascript" src="<?php echo $mosConfig_live_site ?>/js/scriptaculous.js"></script>
		<script type="text/javascript" language="javascript" src="<?php echo $mosConfig_live_site ?>/js/swfobject.js"></script>
		<script type="text/javascript" language="javascript" src="<?php echo $mosConfig_live_site ?>/js/amdance.js"></script>
		<script type="text/javascript" language="javascript" src="<?php echo $mosConfig_live_site ?>/js/dhonishow.js"></script>
		<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-78951204-1', 'auto');
  ga('send', 'pageview');
		</script>
		
	</head>
	<body>