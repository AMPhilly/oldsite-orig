<div id="secondary-nav">
	<table<?php echo $_section == "events-and-news" ? " class=\"active\"" : "" ?> id="sec-nav-1" cellpadding="0" cellspacing="0">
		<tr>
			<td class="sec-top-left"></td>
			<td class="sec-top-mid"></td>
			<td class="sec-top-right"></td>
		</tr>
		<tr>
			<td class="sec-mid-left">&nbsp;</td>
			<td class="sec-mid-mid"><a class="col-1" href="<?= $mosConfig_live_site ?>/events-and-news/upcoming-events.php">Events + News</a></td>
			<td class="sec-mid-right">&nbsp;</td>
		</tr>
		<tr>
			<td class="sec-bot-left"></td>
			<td class="sec-bot-mid"></td>
			<td class="sec-bot-right"></td>
		</tr>
	</table>
	
	<table<?php echo $_section == "photos-and-testimonials" ? " class=\"active\"" : "" ?> id="sec-nav-3" cellpadding="0" cellspacing="0">
		<tr>
			<td class="sec-top-left"></td>
			<td class="sec-top-mid"></td>
			<td class="sec-top-right"></td>
		</tr>
		<tr>
			<td class="sec-mid-left">&nbsp;</td>
			<td class="sec-mid-mid"><a class="col-0" href="<?= $mosConfig_live_site ?>/photos-and-testimonials/emmit-smith-interview.php">Photos + Testimonials</a></td>
			<td class="sec-mid-right">&nbsp;</td>
		</tr>
		<tr>
			<td class="sec-bot-left"></td>
			<td class="sec-bot-mid"></td>
			<td class="sec-bot-right"></td>
		</tr>
	</table>
	
	<table<?php echo $_section == "about-us" ? " class=\"active\"" : "" ?> id="sec-nav-2" cellpadding="0" cellspacing="0">
		<tr>
			<td class="sec-top-left"></td>
			<td class="sec-top-mid"></td>
			<td class="sec-top-right"></td>
		</tr>
		<tr>
			<td class="sec-mid-left">&nbsp;</td>
			<td class="sec-mid-mid"><a class="col-1" href="<?= $mosConfig_live_site ?>/about-us/teaching-method.php">About Us</a></td>
			<td class="sec-mid-right">&nbsp;</td>
		</tr>
		<tr>
			<td class="sec-bot-left"></td>
			<td class="sec-bot-mid"></td>
			<td class="sec-bot-right"></td>
		</tr>
	</table>
	
	<table<?php echo $_section == "getting-started" ? " class=\"active\"" : "" ?> id="sec-nav-4" cellpadding="0" cellspacing="0">
		<tr>
			<td class="sec-top-left"></td>
			<td class="sec-top-mid"></td>
			<td class="sec-top-right"></td>
		</tr>
		<tr>
			<td class="sec-mid-left">&nbsp;</td>
			<td class="sec-mid-mid"><a class="col-2" href="<?= $mosConfig_live_site ?>/getting-started/new-student-offer.php">Getting Started</a></td>
			<td class="sec-mid-right">&nbsp;</td>
		</tr>
		<tr>
			<td class="sec-bot-left"></td>
			<td class="sec-bot-mid"></td>
			<td class="sec-bot-right"></td>
		</tr>
	</table>
</div>