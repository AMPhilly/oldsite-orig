				
				<div id="tert-nav">
					<ul>
						<li<?php echo $_page == "new-student-offer" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-1" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/getting-started/new-student-offer.php">New Student Offer</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
						<li<?php echo $_page == "programs-and-standards" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-2" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/getting-started/programs-and-standards.php">Programs and Standards</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
						<li<?php echo $_page == "weddings" ? " class=\"active\"" : "" ?>>						
							<table id="tert-nav-3" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/getting-started/weddings.php">WEDDING Programs</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
						<li<?php echo $_page == "benefits-of-dancing" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-4" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/getting-started/benefits-of-dancing.php">Benefits of Dancing</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
						<li<?php echo $_page == "gift-certificates" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-5" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/gift-certificates.php">Gift Certificates</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
						<li<?php echo $_page == "free-lesson" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-6" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
							<!--	<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/free-lesson.php">FREE LESSON</a></td>
									<td class="tert-mid-right"></td>
								</tr>-->
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
					</ul>
				</div>