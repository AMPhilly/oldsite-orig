				
				<div id="tert-nav">
					<ul>
						<li<?php echo $_page == "upcoming-events" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-1" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/events-and-news/upcoming-events.php">Upcoming Events</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
						<li<?php echo $_page == "events" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-2" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/events-and-news/events.php">Calendar</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
						<li<?php echo $_page == "news" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-3" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/events-and-news/news.php">Arthur Murray in the News</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
						<li<?php echo $_page == "hot-topics" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-4" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/events-and-news/hot-topics.php">Hot Topics</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
						<li<?php echo $_page == "enews-sign-up" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-5" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/enews-sign-up.php">e-News Sign-Up</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
					</ul>
				</div>