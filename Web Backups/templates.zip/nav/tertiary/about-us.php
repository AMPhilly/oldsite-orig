				
				<div id="tert-nav">
					<ul>
						<li<?php echo $_page == "teaching-method" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-1" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/about-us/teaching-method.php">Teaching Method</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
						<li<?php echo $_page == "history" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-2" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/about-us/history.php">History of Arthur Murray</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
						<!--<li<?php echo $_page == "staff" ? " class=\"active\"" : "" ?>>						
							<table id="tert-nav-3" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/about-us/staff.php">Meet The Staff</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>-->
						<li<?php echo $_page == "dances-we-offer" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-4" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/about-us/dances-we-offer.php">Dances We Offer</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
						<!--<li<?php echo $_page == "dance-dictionary" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-5" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/about-us/dance-dictionary.php">Dance Dictionary</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>-->
						<li<?php echo $_page == "new-student-offer" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-6" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/about-us/new-student-offer.php">New Student Offer</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
					</ul>
				</div>