				
				<div id="tert-nav">
					<ul>
						<li<?php echo $_page == "emmit-smith-interview" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-1" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/photos-and-testimonials/emmit-smith-interview.php">Interview with Emmit Smith</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
						<li<?php echo $_page == "why-dance-infomercial" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-2" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/photos-and-testimonials/why-dance-infomercial.php">"Why Dance?" Infomercial</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
						<li<?php echo $_page == "testimonials" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-3" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/photos-and-testimonials/testimonials.php">Client Testimonials</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
						<li<?php echo $_page == "photo-galleries" ? " class=\"active\"" : "" ?>>
							<table id="tert-nav-4" cellpadding="0" cellspacing="0" align="right">
								<tr>
									<td class="tert-top-left"></td>
									<td class="tert-top-mid"></td>
									<td class="tert-top-right"></td>
								</tr>
								<tr>
									<td class="tert-mid-left"></td>
									<td class="tert-mid-mid"><a href="<?php echo $mosConfig_live_site ?>/photos-and-testimonials/photo-galleries.php">Studio Photo Gallery</a></td>
									<td class="tert-mid-right"></td>
								</tr>
								<tr>
									<td class="tert-bot-left"></td>
									<td class="tert-bot-mid"></td>
									<td class="tert-bot-right"></td>
								</tr>
							</table>
						</li>
					</ul>
				</div>