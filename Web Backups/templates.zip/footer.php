		
		<div id="banner-cont"><div id="banner"><a href="<?= $mosConfig_live_site ?>/photos-and-testimonials/emmit-smith-interview.php"><img src="<?= $mosConfig_live_site ?>/images/<?= $mosConfig_theme ?>/banner-1.jpg" alt="Dance studio providing lessons in dance" /></a><a href="<?php echo $mosConfig_live_site ?>/tv-commercials.php"><img src="<?= $mosConfig_live_site ?>/images/<?= $mosConfig_theme ?>/banner-2.jpg" alt="Dance lessons in Philadelphia, Narberth, Ardmore, and the Main Line" /></a><a href="<?= $mosConfig_live_site ?>/contact-us.php"><img src="<?= $mosConfig_live_site ?>/images/<?= $mosConfig_theme ?>/banner-3.jpg" alt="Dance studio in Philadelphia, Narberth, Ardmore, and the Main Line" /></a><a href="<?= $mosConfig_live_site ?>/contact-us.php"><img src="<?= $mosConfig_live_site ?>/images/<?= $mosConfig_theme ?>/banner-4.jpg" alt="Dance lessons, samba, wedding, salsa" /></a></div>
</div>
		<div id="footer-cont">
			<div id="footer" align="right"><a href="<?php echo $mosConfig_live_site ?>/referral-program.php">Referral Program</a> <a href="<?php echo $mosConfig_live_site ?>/links.php">Links</a> <a href="<?php echo $mosConfig_live_site ?>/employment.php">Employment Opportunity</a><br/><a href="http://amdancestudio.com/about-us/teaching-method.php">© Copyright 2011 AMdancestudio.com – Best dance studios and schools for<br/> Ballroom dancing, Tango, Salsa dance classes and Private dance lessons in the Philadelphia Areas.</a></div></div>

		<script src="http://maps.google.com/maps?file=api&amp;v=2&amp;key=ABQIAAAAqu44n4iPiDq-dlRdfxo2YBSdHHN8u0wnn9e1V2-jWihwhFvS1RQBz3PzQkj61WgL3eKM9T4t3Ig27A" type="text/javascript"></script>
		
        <script src='http://widget.rlcdn.net/widget/rl_chatwidget.js'></script><script>var id ='USA2333587'; var rl_adid='113836'; var rl_key = '213940'; rl_chatinit(id, rl_adid, rl_key) ;</script>
	</body>
    <img src="http://ad.reachlocal.com/pixel?id=1415107&id=1415120&t=2" width="1" height="1" />
   <script type="text/javascript"> adroll_adv_id = "XQDI6E67ZFHVJODLCQOMPD"; adroll_pix_id = "236723QNQFGUPITS3VJXL6"; (function () { var oldonload = window.onload; window.onload = function(){ __adroll_loaded=true; var scr = document.createElement("script"); var host = (("https:" == document.location.protocol) ? "https://s.adroll.com" : "http://a.adroll.com"); scr.setAttribute('async', 'true'); scr.type = "text/javascript"; scr.src = host + "/j/roundtrip.js"; ((document.getElementsByTagName('head') || [null])[0] || document.getElementsByTagName('script')[0].parentNode).appendChild(scr); if(oldonload){oldonload()}}; }()); </script> 
   <img src="http://ad.reachlocal.com/pixel?id=1415081&id=1415090&t=2" width="1" height="1" />
</html>
