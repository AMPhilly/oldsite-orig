<?php require_once("common-header.php"); ?>

		<div id="interior-header-cont">
			<div id="interior-header">
				<a href="<?= $mosConfig_live_site ?>"><img src="<?= $mosConfig_live_site ?>/images/<?= $mosConfig_theme ?>/logo-interior.jpg" alt="Philadelphia area dance studio" id="interior-logo" /></a>
				<img src="<?= $mosConfig_live_site ?>/images/petitefeet.gif" alt="Philadelphia area dance lessons" id="interior-tinydancer" />
				<?php require_once("nav/primary.php"); ?>
				<?php require_once("nav/secondary.php"); ?>
			</div>
	</div>