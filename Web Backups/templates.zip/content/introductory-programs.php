<h1>Introductory Programs</h1>

<p>
	Arthur Murray offers an introductory program with special pricing for the first-time student*.
</p>
<h2>X lessons for just $XXX! </h2> 
<p>
	It's quick and easy to sign up online when you use Paypal.  Or, if you know of someone who would like to start taking dance lessons, you can purchase a gift certificate in the amount of the introductory program.
</p>
<p class="disclaimer">
	*First-time students eligible.  May not be combined with other offers.
</p>