<?php require_once("common-header.php"); ?>
		<map name="Map" id="Map">
      <area shape="rect" coords="37,1,144,28" href="http://twitter.com/amphilly" />
			<area shape="rect" coords="146,2,232,28" href="http://www.facebook.com/ArthurMurrayPhiladelphia" />
	</map>
		<div id="header-cont">
			<div id="header">
				<img src="<?= $mosConfig_live_site ?>/images/socialnetworks.gif" border="0" usemap="#Map" id="social-links" />
				<img src="<?= $mosConfig_live_site ?>/images/tinydancer.gif" alt="Dance lessons and instruction" id="home-tinydancer" />
				<?php require_once("nav/primary.php"); ?>
				<?php require_once("nav/secondary.php"); ?>
			</div>
</div>