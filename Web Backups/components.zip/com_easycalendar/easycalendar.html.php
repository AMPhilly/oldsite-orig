<?php
/**
* @package Easy Calendar
* @copyright (C) 2006 Joomla-addons.org
* @author Websmurf
* 
* --------------------------------------------------------------------------------
* All rights reserved.  Easy Calender Component for Joomla!
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the Creative Commons - Attribution-NoDerivs 2.5 
* license as published by the Creative Commons Organisation
* http://creativecommons.org/licenses/by-nd/2.5/.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
* --------------------------------------------------------------------------------
**/

defined( '_VALID_MOS' ) or die( 'Restricted access' );

class HTML_easycalendar {
  
  /**
   * Show month view
   *
   * @param array $rows
   * @param int $month
   * @param int $year
   */
  function showMonth($rows, $month, $year){
    global $option, $mainframe, $Itemid, $database;
	
	// Retrieve PDF
	$sql = "SELECT PDF FROM #__calendarpdf WHERE Month = ".$month." AND Year = ".$year;
	$database->setQuery($sql);
	$PDF = $database->loadResult();
    
    mosCommonHTML::loadOverlib();
    
    $mainframe->addCustomHeadTag('<link href="'.$mainframe->getCfg('live_site') . '/components/com_easycalendar/easycalendar.css" rel="stylesheet" type="text/css"/>'); 
    
    $starttime = strtotime($year . '-' . $month . '-01 12:00:00');
    $endtime = strtotime($year . '-' . $month . '-'. date('t', $starttime) . ' 12:00:00');
    
    $firstday = date('w', $starttime);
    $firstday = $firstday == 0 ? 7 : $firstday; //correct, monday as start day
    $lastday = date('w', $endtime);
    $lastday = $lastday == 0 ? 7 : $lastday; //correct, monday as start day
    
    if($firstday != 1){
      $first = $starttime - (($firstday - 1) * (60*60*24));
    } else {
      $first = $starttime;
    }
    if($lastday != 7){
      $last = $endtime + ((7 - $lastday) * (60*60*24));
    } else {
      $last = $endtime;
    }
    
    if($month == 10){
      $last = $last - (60*60*24);
    }
    
	if($PDF != "")
	{
		$pdf_link = ' - <a style="color: black; font-size: 12px;" href="'.$mainframe->getCfg('live_site').'/data/calendarpdf/pdf/'.$PDF.'" target="_blank">Download Calendar</a>';
	}
	else
	{
		$pdf_link = '';
	}
	
    $mainframe->setPageTitle(sprintf(EC_VIEW_MONTH, strftime('%B', $starttime), $year));
    echo '<div class="componentheading">' . sprintf(EC_VIEW_MONTH, strftime('%B', $starttime), $year) . $pdf_link . '</div>';
    
    $p_month = $month - 1;
    $p_year = $year;
    if($p_month < 1){
      $p_year--;
      $p_month = 12;
    }
    $n_month = $month + 1;
    $n_year = $year;
    if($n_month > 12){
      $n_year++;
      $n_month = 1;
    }
    
    echo '<a href="' . $mainframe->getCfg('live_site') . '/events-and-news/events/' . $p_year . '/' . $p_month . '/' . '" title="' . EC_PREV_MONTH . '"><img src="'.$mainframe->getCfg('live_site').'/components/com_easycalendar/icons/22x22_back.png" border="0" alt="' . EC_PREV_MONTH . '" /></a>';
    echo '&nbsp;';
    echo '<a href="' . $mainframe->getCfg('live_site') . '/events-and-news/events/' . $n_year . '/' . $n_month . '/' . '" title="' . EC_NEXT_MONTH . '"><img src="'.$mainframe->getCfg('live_site').'/components/com_easycalendar/icons/22x22_forward.png" border="0" alt="' . EC_NEXT_MONTH . '" /></a>';
    
    echo '<div class="heading">' . strftime('%a', $first) . '</div>';
    echo '<div class="heading">' . strftime('%a', $first + (1 * 60*60*24)) . '</div>';
    echo '<div class="heading">' . strftime('%a', $first + (2 * 60*60*24)) . '</div>';
    echo '<div class="heading">' . strftime('%a', $first + (3 * 60*60*24)) . '</div>';
    echo '<div class="heading">' . strftime('%a', $first + (4 * 60*60*24)) . '</div>';
    echo '<div class="heading">' . strftime('%a', $first + (5 * 60*60*24)) . '</div>';
    //echo '<div class="heading">' . strftime('%a', $first + (6 * 60*60*24)) . '</div>';
    
    for($i=$first;$i<$last+(60*60*24);$i=$i+(60*60*24)){
//      echo date('d-m-Y H:i:s', $i) . '|' . $i . '<br />';
      if(date('w', $i) == 1){ //first day
        echo '<br clear="all" />';
      }
	  
	  if(date('w', $i) > 0)
	  {
      
      echo '<div class="day">';
      echo '<span class="heading' . (date('m', $i) == $month ? ' active' : '')  . '">' . date('j', $i) . '</span>';
      if(isset($rows[date('Y-m-d', $i)])){
        if(isset($rows[date('Y-m-d', $i)]['allday'])){ //list all allday events
          for($j=0,$n=count($rows[date('Y-m-d', $i)]['allday']);$j<$n;$j++){
            $row = $rows[date('Y-m-d', $i)]['allday'][$j];
            
            $row->description = str_replace(array("\n", "\r"), '', $row->description);
            $row->description = addslashes($row->description);
            
			$link = $mainframe->getCfg('live_site') . '/events-and-news/events/view/' . $row->id.'/'.$Itemid.'/';
            //$link = sefRelToAbs('index.php?option=' . $option . '&amp;task=view&amp;id=' . $row->id . '&amp;Itemid=' . $Itemid);
            
			echo '<span class="event allday cat' . $row->cid . '"><a href="'.$link.'">' . mosToolTip($row->description, $row->name, '', null, substr($row->name, 0, 100), $link) . '</span>';
           // echo '<span class="event allday cat' . $row->cid . '">' . mosToolTip($row->description, $row->name, '', null, substr($row->name, 0, 12), $link) . '</span>'; // Tool tip version
          }
        }
        
        if(isset($rows[date('Y-m-d', $i)]['regular'])){ //list all regular events
          for($j=0,$n=count($rows[date('Y-m-d', $i)]['regular']);$j<$n;$j++){
            $row = $rows[date('Y-m-d', $i)]['regular'][$j];
            
            $row->description = str_replace(array("\n", "\r"), '', $row->description);
            $row->description = addslashes($row->description);
            
            $link = $mainframe->getCfg('live_site') . '/events-and-news/events/view/' . $row->id.'/';
            
            $starttime = explode(":", substr($row->starttime, 0, 5));
			if($starttime[0] > 12)
			{
				$stime = intval($starttime[0]) - 12;
				$stime .= ":".$starttime[1];
			}
			else
				$stime = $starttime[0].":".$starttime[1];
			echo '<span class="event regular cat' . $row->cid . '"><a href="'.$link.'">' . $stime . ' ' . substr($row->name, 0, 100) . '</a></span>';
			//echo '<span class="event regular cat' . $row->cid . '">' . mosToolTip($row->description, $row->name, '', null, substr($row->starttime, 0, 5) . ' ' . substr($row->name, 0, 10), $link) . '</span>'; // Tooltip version
          }
        }
      }
      echo '</div>';
	  }
    }
  }
  
  /**
   * Show upcoming events
   *
   * @param array $rows
   */
  function showUpcoming($rows){
    global $option, $Itemid, $mainframe;
    
    $mainframe->setPageTitle(EC_VIEW_UPCOMING);
    $mainframe->appendPathWay(EC_VIEW_UPCOMING);
    
    echo '<div class="componentheading">' . EC_VIEW_UPCOMING . '</div>';
    
    echo '<table width="100%" cellpadding="0" cellspacing="0">';
    echo '<tr>';
    echo '<th class="sectiontableheader">'. EC_EVENT_NAME . '</th>';
    echo '<th class="sectiontableheader">'. EC_EVENT_DATE . '</th>';
    echo '<th class="sectiontableheader">'. EC_EVENT_TIME . '</th>';
    echo '<th class="sectiontableheader">'. EC_EVENT_CATEGORY . '</th>';
    
    echo '</tr>';
    for($i=0,$n=count($rows);$i<$n;$i++){
      $row = $rows[$i];
      
      $link = sefRelToAbs('index.php?option=' . $option . '&amp;task=view&amp;id=' . $row->id . '&amp;Itemid=' . $Itemid);
      
      echo '<tr>';
      echo '<td><a href="' . $link . '">' . $row->name . '</a></td>';
      echo '<td>' . ($row->startdate == $row->enddate ? mosFormatDate($row->startdate . ' ' . $row->starttime, EC_DATE_FORMAT) : mosFormatDate($row->startdate . ' ' . $row->starttime, EC_DATE_FORMAT) . ' - ' . mosFormatDate($row->enddate . ' ' . $row->endtime, EC_DATE_FORMAT)) . '</td>';
      echo '<td>' . ($row->starttime == $row->endtime ? EC_ALL_DAY : mosFormatDate($row->startdate . ' ' . $row->starttime, EC_TIME_FORMAT) . ' - ' . mosFormatDate($row->enddate . ' ' . $row->endtime, EC_TIME_FORMAT)) . '</td>';
      echo '<td>' . $row->category . '</td>';
      echo '</tr>';
    }
    
    echo '</table>';
  }
  
  /**
   * View event details
   *
   * @param dbEvent $row
   */
  function viewEvent($row, $params){
    global $option, $Itemid, $mainframe;
    
    $mainframe->setPageTitle(sprintf(EC_VIEW_EVENT, $row->name));
    $mainframe->appendPathWay(sprintf(EC_VIEW_EVENT, $row->name));
    
    //echo '<div class="componentheading">' . sprintf(EC_VIEW_EVENT, $row->name) . '</div>';
    
    echo '<table width="100%" cellpadding="0" cellspacing="0">';
    echo '<tr><td width="110"><p><strong>' . EC_EVENT_NAME . ':</strong></p></td><td><p><strong>' . $row->name . '</strong></p></td></tr>';
    echo '<tr><td><p><strong>' . EC_EVENT_CATEGORY . ':</strong></p></td><td><p>' . $row->category->name . '</p></td></tr>';
    echo '<tr><td><p><strong>' . EC_EVENT_DATE . ':</strong></p></td><td><p>' . ($row->startdate == $row->enddate ? mosFormatDate($row->startdate . ' ' . $row->starttime, EC_DATE_FORMAT) : mosFormatDate($row->startdate . ' ' . $row->starttime, EC_DATE_FORMAT) . ' - ' . mosFormatDate($row->enddate . ' ' . $row->endtime, EC_DATE_FORMAT)) . '</p></td></tr>';
    echo '<tr><td><p><strong>' . EC_EVENT_TIME . ':</strong></p></td><td><p>' . ($row->starttime == $row->endtime ? EC_ALL_DAY : mosFormatDate($row->startdate . ' ' . $row->starttime, EC_TIME_FORMAT) . ' - ' . mosFormatDate($row->enddate . ' ' . $row->endtime, EC_TIME_FORMAT)) . '</p></td></tr>';
    echo '<tr valign="top"><td><p><strong>' . EC_EVENT_DESCRIPTION . ':</strong></p></td><td><p>' . $row->description . '</p></td></tr>';
    echo '</table>';
	
	?><p><a class="big-red" href="<?php echo $mainframe->getCfg('live_site') ?>/events-and-news/events">Back to Calendar</a></p><?php
  }
  
  
  
  /**
   * Show copyright notices
   */
  function showCopyright(){
    global $mainframe;

    /**
     * Visible copyright notices, you can remove it if you like
     */
    echo '<div class="small" style="clear: both;"><br />'. EC_POWEREDBY . ' <a href="http://www.joomla-addons.org/easy-calendar-component.html" target="_blank">Easy Calendar</a> &copy; 2006 <a href="http://www.joomla-addons.org" target="_blank" title="Joomla components, modules, plugins and hosting">Joomla-addons.org</a></div>';

    /**
     * I would appreciate it very much if you could leave this present,
     * this is something your users will never see
     */
    $mainframe->addMetaTag('Generator', 'Easy Calendar by www.joomla-addons.org');
  }
  
}

?>