<?php
/**
* @package Easy Calendar
* @copyright (C) 2006 Joomla-addons.org
* @author Websmurf
* 
* --------------------------------------------------------------------------------
* All rights reserved.  Easy Calender Component for Joomla!
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the Creative Commons - Attribution-NoDerivs 2.5 
* license as published by the Creative Commons Organisation
* http://creativecommons.org/licenses/by-nd/2.5/.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
* --------------------------------------------------------------------------------
**/

defined( '_VALID_MOS' ) or die( 'Restricted access' );

/** general **/
define('EC_DATE_FORMAT', '%m/%d/%Y');
define('EC_TIME_FORMAT', '%I:%M %p');

/** view upcoming **/
define('EC_VIEW_UPCOMING', 'View upcoming events');

/** view event **/
define('EC_VIEW_EVENT', 'View \'%s\' details');
define('EC_EVENT_NAME', 'Name');
define('EC_EVENT_DATE', 'Date');
define('EC_EVENT_TIME', 'Time');
define('EC_ALL_DAY', 'All day');
define('EC_EVENT_CATEGORY', 'Category');
define('EC_EVENT_DESCRIPTION', 'Description');

/** month view **/
define('EC_VIEW_MONTH', '%s %s');
define('EC_NEXT_MONTH', 'Next month');
define('EC_PREV_MONTH', 'Previous month');

/** showCopyright **/
define('EC_POWEREDBY', 'Powered by');

?>